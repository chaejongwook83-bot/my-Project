<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>


<view:view id="LOV_ITEM_PLANT" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="플랜트">
        <view:buttons>
            <view:button id="CLOSE"  label="닫 기" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="LOV_ITEM_PLANT">
        <search:so cols="2" rows="1"  fixedRows="0">

            <search:so_keyword     row="1" col="1"  selectedListItemId="2"  keyword="" >
                <search:so_keyword_item id="1" label="플랜트"      value="1" columnName="PLANT_NAME" />
            </search:so_keyword>

            <search:so_keyword     row="1" col="2"  selectedListItemId="2"  keyword="" >
                <search:so_keyword_item id="1" label="플랜트코드"   value="1" columnName="PLANT_CODE" />
            </search:so_keyword>
            <search:so_paging rowsPerPage="500" />

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="LOV_ITEM_PLANT">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="LOV_ITEM_PLANT">
        <grid:grid     showCheck="true"  sortColumnId="ITEM_PLANT_UID" sortDirection="ASC"   >
            <grid:column_txt   id="PLANT_NAME"                       name="플랜트"           edit="<%=GridEditType.READ_ONLY%>" align="left"      width="120" />
            <grid:column_txt   id="ITEM_GROUP_CODE"                  name="상품그룹코드"     edit="<%=GridEditType.READ_ONLY%>" align="center"    width="90"  />
            <grid:column_txt   id="ITEM_GROUP_NAME"                  name="상품그룹명"       edit="<%=GridEditType.READ_ONLY%>" align="left"      width="120" />
            <grid:column_txt   id="PURCHASE_GROUP_CODE"              name="소싱그룹코드"     edit="<%=GridEditType.READ_ONLY%>" align="center"    width="120" />
            <grid:column_txt   id="PURCHASE_GROUP_NAME"              name="소싱그룹명"       edit="<%=GridEditType.READ_ONLY%>" align="left"      width="120" />
            
            <grid:hidden        id="CLIENT_CODE"		columnName="CLIENT_CODE"            />
            <grid:hidden        id="PLANT_CODE"		    columnName="PLANT_CODE"            />
            <grid:hidden        id="COMPANY_CODE"		columnName="COMPANY_CODE"           />
            <grid:hidden        id="ITEM_UID"			columnName="ITEM_UID"	        sortColumn="ITEM_UID"/>
            <grid:hidden        id="ITEM_PLANT_UID"     columnName="ITEM_PLANT_UID"     sortColumn="ITEM_PLANT_UID"/>
            <grid:hidden        id="ITEM_COMPANY_UID"   columnName="ITEM_COMPANY_UID"   />


        </grid:grid>
    </view:view_grid>

</view:view>

<script>

   function initPage(){
	   
	   doSearch();
	   
   }


</script>