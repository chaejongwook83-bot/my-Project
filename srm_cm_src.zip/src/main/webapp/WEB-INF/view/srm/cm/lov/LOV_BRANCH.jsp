<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp" %>


<view:view id="LOV_BRANCH" type="<%= ViewType.LOV %>" session="<%=session%>" model="<%=request%>">

    <view:title name="점소">
        <view:buttons>
            <view:button id="CLOSE" label="닫기"/>
        </view:buttons>
    </view:title>

    <view:view_so groupId="LOV_BRANCH">
        <search:so cols="2" rows="1" fixedRows="0">

            <search:so_keyword row="1" col="1" selectedListItemId="1" keyword="">
                <search:so_keyword_item id="1" label="점소코드" value="1" columnName="BRSH_CD"/>
            </search:so_keyword>

            <search:so_keyword row="1" col="2" selectedListItemId="1" keyword="">
                <search:so_keyword_item id="1" label="점소명" value="1" columnName="BRSH_NM"/>
            </search:so_keyword>

            <search:so_paging rowsPerPage="500"/>

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="LOV_BRANCH">
        <toolbar:toolbar showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH" label="조 회" href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="LOV_BRANCH">
        <grid:grid sortColumnId="BRSH_CD" sortDirection="ASC">
            <grid:column_txt id="STAT" name="상태" width="100" align="center"/>
            <grid:column_txt id="BRSH_CD" name="점소코드" width="100" align="center" sortColumn="BRSH_CD"/>
            <grid:column_txt id="BRSH_NM" name="점소명" width="120" align="center" />
            <grid:column_date id="ESTB_YMD" name="개설일자" formatter="<%=FMTType.DATE%>" width="120" align="center"/>
            <grid:column_date id="CLOS_YMD" name="만료일자" formatter="<%=FMTType.DATE%>" width="120" align="center"/>
        </grid:grid>
    </view:view_grid>

</view:view>

<script>

</script>