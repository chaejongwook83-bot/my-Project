<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>

<style>
    #canvas {
        border: 1px solid black;
        cursor: crosshair;
    }
</style>


<view:view id="LOV_SIGNATURE" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="사용자 서명">
        <view:buttons>
            <view:button id="CLOSE"  label="닫기" />
        </view:buttons>
    </view:title>

    <entry:conts>
        <canvas id="canvas" width="400" height="200"></canvas>
        <div class="col-12 btn-area float-right">
            <entry:button id="sign"       label="서명"   href="sign()"      cssClass="float-right ml-1" />
            <entry:button id="clearSign"  label="초기화" href="clearSign()" cssClass="float-right" />
        </div>
    </entry:conts>

</view:view>

<script>

    $(document).ready(function(){
        var canvas = document.getElementById('canvas');
        var ctx = canvas.getContext('2d');
        var isDrawing = false;

        // Event listeners for mouse/touch events
        canvas.addEventListener('mousedown', startDrawing);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', stopDrawing);
        canvas.addEventListener('touchstart', startDrawing);
        canvas.addEventListener('touchmove', draw);
        canvas.addEventListener('touchend', stopDrawing);

        function startDrawing(e) {
            isDrawing = true;
            draw(e);
        }

        function draw(e) {
            if (!isDrawing) return;

            // Get the current position of the cursor/finger
            var x, y;
            if (e.type.startsWith('mouse')) {
                x = e.clientX - canvas.getBoundingClientRect().left;
                y = e.clientY - canvas.getBoundingClientRect().top;
            } else if (e.type.startsWith('touch')) {
                x = e.touches[0].clientX - canvas.getBoundingClientRect().left;
                y = e.touches[0].clientY - canvas.getBoundingClientRect().top;
            }

            // Draw a line to the current position
            ctx.lineTo(x, y);
            ctx.stroke();
        }

        function stopDrawing() {
            isDrawing = false;
            ctx.beginPath(); // Start a new drawing path
        }
    })

    /**
     * 서명생성
     */
    function sign(){
        var signatureData = canvas.toDataURL();
        try{
            parent.lovSetValueCallBack({signature:signatureData}, $("input[name='LOV_PARAMETER_INF_ID']").val());
            closeModalWindow();
        }catch(e){
            console.dir(e.stack);
        }
    }

    /**
     * 서명초기화
     */
    function clearSign(){
        var canvas = document.getElementById('canvas');
        var ctx = canvas.getContext('2d');

        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

</script>