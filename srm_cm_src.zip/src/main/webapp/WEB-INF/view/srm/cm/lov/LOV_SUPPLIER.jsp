<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>


<view:view id="LOV_SUPPLIER" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="파트너사">
        <view:buttons>
            <view:button id="CLOSE"   label="닫기" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="SUPPLIER">
        <search:so cols="2" rows="2"  fixedRows="2">

            <search:so_keyword     row="1" col="1"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="파트너사 코드" value="1" columnName="SUPPLIER_CODE" />
            </search:so_keyword>

            <search:so_keyword     row="1" col="2"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="파트너사 명" value="1" columnName="SUPPLIER_NAME"  />
            </search:so_keyword>

             <search:so_keyword     row="2" col="1"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="사업자등록번호" value="2" columnName="BUSINESS_NUMBER" />
            </search:so_keyword>

            <search:so_paging rowsPerPage="500" />

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="SUPPLIER">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="SUPPLIER">
        <grid:grid     showCheck="true"  sortColumnId="SUPPLIER_CODE" sortDirection="ASC"   >
            <grid:column_txt    id="SUPPLIER_CODE"          name="파트너사 코드"         width="120" align="center" sortColumn="SUPPLIER_CODE"/>
            <grid:column_txt    id="SUPPLIER_NAME"          name="파트너사 명"           width="150" align="left"   />
            <grid:column_txt    id="SCG_NAME"               name="구매그룹"           width="100" align="left"   />
            <grid:column_txt    id="BUSINESS_NUMBER"        name="사업자등록번호"     width="110" align="left"   />
            <grid:column_txt    id="CEO_NAME"             name="대표이사"           width="080" align="left"   />
            <grid:column_txt    id="BUSINESS_CONDITION"     name="업태"               width="100" align="left"   />
            <grid:column_txt    id="BUSINESS_CATEGORY"      name="업종"               width="200" align="left"   />
            <grid:column_txt    id="ADDRESS"                name="주소"               width="180" align="left"   />

            <grid:hidden        id="SUPPLIER_UID"           columnName="SUPPLIER_UID"           />
            <grid:hidden        id="USER_NAME"              columnName="USER_NAME"              />
            <grid:hidden        id="MOBILE_NO"              columnName="MOBILE_NO"              />
            <grid:hidden        id="EMAIL"                  columnName="EMAIL"                  />
        </grid:grid>
    </view:view_grid>

</view:view>

<script>
    function initPage(){
        $("input[name='KEYWORD_KEYWORD2']").focus();
    }
</script>