<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>

<input type="hidden" name="EDIT_FLAG" value="${EDIT_FLAG}"/>
<input type="hidden" name="REJECT_FLAG" value="${REJECT_FLAG}"/>

<view:view id="LOV_RFQ_REASON" type="<%= ViewType.MODAL %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="사유등록">
        <view:buttons>
            <view:button id="SEND"    label="사유등록" href="doSend()" />
            <view:button id="END_CLOSE"   label="닫기"  href="closeModalWindow()" />
        </view:buttons>
    </view:title>

    <c:if test="${REJECT_FLAG eq 'Y'}">
        <entry:groupInfo>
            <div class="form-group">
                <strong>※ 사유를 등록하고 "사유등록" 버튼을 누르면 입찰 참여가 포기됩니다.<br>
                    ※ 한번 포기한 입찰 건은 <span style="color:red; font-size: 18px;">참여가 절대 불가능</span>하오니 신중히 진행해 주시기 바랍니다.
                </strong>
            </div>
        </entry:groupInfo>
    </c:if>

    <entry:conts>
        <div class="form-group row">
            <div class="col">
                <entry:textarea id="REASON" showLabel="false" label="사유" rows="7"   value="${REASON }" htmlAttribute="onKeyUp='fnChkByte()'" cssClass="col"  />
            </div>
        </div>

        <div class="form-group row">
            <div class="col text-right">
                <font color="red"><span id="byteInfo">0</span></font>/2000 Byte
            </div>

        </div>
    </entry:conts>


</view:view>

<script>

    $(document).ready(function() {

        createHiddenParameter();
        fnChkByte();
        controlObj();
    });

    function controlObj(){
        if("${EDIT_FLAG}" === 'Y'){
            $(".titNav").find("h2").text(function(index, currentText) {
                return currentText.replace("등록", "상세");
            });
            controlButton("SEND",false);
            controlComponent("REASON","readonly");
        }
    }

    /**
     * 등록버튼
     */
    function doSend() {
        var f = document.forms[0];

        if (f.elements["REASON"].value.byteLength() == 0) {
            alert(f.elements["REASON"].getAttribute('hname') +   mwfMsg.message('CO_0021')); //은(는) 반드시 입력하셔야 합니다.
            f.elements["REASON"].focus();
            return false;
        }
        if (f.elements["REASON"].value.byteLength() > 2000) {
            alert(formatMessage(mwfMsg.message('CO_0054'), "2000") ); // "%sByte 이하 입력하셔야 합니다.";
            return false;
        }

        parent.doReasonInput(f.elements["PARENT_ACTION_ID"].value, f.elements["REASON"].value);
        closeModalWindow();
    }

    /**
     * Byte 계산
     */
    function fnChkByte() {
        var f = document.forms[0];
        var rbyte = f.elements["REASON"].value.byteLength();
        document.getElementById('byteInfo').innerText = rbyte;
        if(rbyte > 2000) {
            alert(formatMessage(mwfMsg.message('CO_0054'), "2000") ); // "%sByte 이하 입력하셔야 합니다.";
            return false;
        }
    }

    /**
     * 글자 바이트
     */
    String.prototype.byteLength = function() {
        var l= 0;

        for(var idx=0; idx < this.length; idx++) {
            var c = escape(this.charAt(idx));

            if( c.length==1 ) l ++;
            else if( c.indexOf("%u")!=-1 ) l += 2;
            else if( c.indexOf("%")!=-1 ) l += c.length/3;
        }

        return l;
    };





</script>