<%@ page contentType="text/html; charset=UTF-8" %>

<%-- lov 공용 include --%>
<%@ include file="/WEB-INF/view/ca/layout/fragment/lov_script.jsp"%>

<script>

function createHiddenParameter(){
	
}

</script>

 <input type="hidden" name="LOV_PARAMETER_INF_ID"   value="${LOV_PARAMETER_INF_ID}"/>
 <input type="hidden" name="LOV_COMPANY_CODE"       value="${COMPANY_CODE}"/>