<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>


<view:view id="LOV_PR_CS_ITEM" type="<%= ViewType.MODAL %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="서비스">
        <view:buttons>
            <view:button id="CLOSE"   label="닫기" />
        </view:buttons>
    </view:title>


    <view:view_grid groupId="PR_CS_ITEM">
        <grid:grid     showCheck="false"     >
            <grid:column_txt   id="PR_LINE_NO"              name="항번"              edit="${GridEditType.READ_ONLY}" align="center"      width="050" />
            <grid:column_txt   id="SERVICE_NO"              name="서비스번호"           edit="<%=GridEditType.READ_ONLY%>"    align="left"       width="180"  />
            <grid:column_txt   id="ITEM_DESCRIPTION"                     name="내역"               edit="<%=GridEditType.READ_ONLY%>" align="left"       width="300"  />
            <grid:column_num   id="QUANTITY"                             name="수량"               edit="<%=GridEditType.READ_ONLY%>" align="right"      width="100"  formatter="<%=FMTType.QTY %>" fillZero="false" onValidate="calcAmount(grid, value, 'UNIT_PRICE')" />
            <grid:column_txt   id="QUANTITY_UNIT"                        name="단위"               edit="<%=GridEditType.READ_ONLY%>" align="center"     width="060"   />
            <grid:column_num   id="UNIT_PRICE"                           name="금액"               edit="<%=GridEditType.READ_ONLY%>" align="right"      width="100"  formatter="<%=FMTType.PRICE %>" currency="KRW"  onValidate="calcAmount(grid, value, 'QUANTITY')" />
            <grid:column_num   id="AMOUNT"                               name="총 가격"               edit="<%=GridEditType.READ_ONLY%>" align="right"      width="110"  formatter="<%=FMTType.AMT %>" currency="KRW"  />
            <grid:column_txt   id="AMOUNT_UNIT"                          name="통화"               edit="<%=GridEditType.READ_ONLY%>" align="center"     width="080"   />
            <grid:column_txt   id="COST_CENTER_CODE"                     name="코스트센터"            edit="<%=GridEditType.READ_ONLY%>"    align="left"       width="120"  />
            <grid:column_txt   id="LINE_DESCRIPTION"                     name="라인텍스트"               edit="<%=GridEditType.READ_ONLY%>" align="left"       width="300"  />

            <grid:hidden   id="PR_H_UID"                            columnName="PR_H_UID"                 />
            <grid:hidden   id="PR_D1_UID"                           columnName="PR_D1_UID"                 />
            <grid:hidden   id="PR_L2_UID"                           columnName="PR_L2_UID"                 />
        </grid:grid>
    </view:view_grid>

</view:view>

<script>
    function initPage(){
doSearch();
    }
</script>