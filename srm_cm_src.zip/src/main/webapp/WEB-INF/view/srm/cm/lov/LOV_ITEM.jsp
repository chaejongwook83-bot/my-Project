<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>

<input type="hidden" name="PARAM_ITEM_CLASS_CODE" value="" />


<view:view id="LOV_ITEM" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="자재정보">
        <view:buttons>
            <view:button id="CLOSE"  label="닫 기" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="LOV_ITEM">
        <search:so cols="2" rows="3"  fixedRows="0">

            <search:so_keyword     row="1" col="1"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="자재내역"      value="1" columnName="I.ITEM_NAME" />
                <search:so_keyword_item id="2" label="자재코드"      value="2" columnName="I.ITEM_CODE" />
            </search:so_keyword>

            <search:so_keyword     row="1" col="2"  selectedListItemId="2"  keyword="" multi="true" >
                <search:so_keyword_item id="1" label="자재코드"      value="1" columnName="I.ITEM_CODE" />
            </search:so_keyword>

            <search:so_lov         row="2" col="1"  selectedListItemId="1"  multi=""  >
                <search:so_lov_item id="1" label="자재분류" value="1" columnName="" customSql=" I.ITEM_CLASS_CODE LIKE ':SEARCHOPTION_VALUE%'" htmlAttribute="callModalDialogN('/mdm/lov/LOV_ITEM_CLASS','FORWARD','ITEM_CLASS_CODE','CLIENT_CODE=${_user.clientCode}', '',  '' , '' , '410', '660')" />
            </search:so_lov>
            
<%--            <search:so_keyword         row="2" col="2"  selectedListItemId="1"  multi=""  >
                <search:so_keyword_item id="1" label="플랜트" value="1" columnName="FN_CO_PLANT_NAME(IP.CLIENT_CODE, IP.COMPANY_CODE, IP.PLANT_CODE)"  />
            </search:so_keyword>--%>

            <search:so_keyword         row="2" col="2"  selectedListItemId="2"  multi=""  >
                <search:so_keyword_item id="1" label="자재유형코드" value="1" columnName="I.MATERIAL_TYPE_CODE"  />
                <search:so_keyword_item id="2" label="자재유형명" value="2" columnName="FN_CO_COMMON_CODE(I.CLIENT_CODE, IC.COMPANY_CODE, 'G', 'MATERIAL_TYPE', I.MATERIAL_TYPE_CODE, null)"  />
            </search:so_keyword>

            <search:so_code  id="L1_ITEM_CLASS_CODE"      label="대/중/소 분류"    row="3" col="1" keyword="" colspan="2" codeType="<%=CodeType.QUERY%>" htmlAttribute="onChange='changeClassCode(1);'" >
                <search:so_code_item id="1" label="전체" value="" columnName="" resultSetId="soClassLevel1"  />
            </search:so_code>

            <search:so_code   id="L2_ITEM_CLASS_CODE"     label="중분류"    row="3" col="1" keyword="" htmlAttribute="onChange='changeClassCode(2);'" >
                <search:so_code_item id="1" label="전체" value="" columnName=""  />
            </search:so_code>

            <search:so_code    id="L3_ITEM_CLASS_CODE"    label="소분류"    row="3" col="1" keyword="" htmlAttribute="onChange='changeClassCode(3);'" >
                <search:so_code_item id="1" label="전체" value="" columnName=""  />
            </search:so_code>

            <search:so_paging rowsPerPage="500" />

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="LOV_ITEM">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="LOV_ITEM">
        <grid:grid     showCheck="true"  sortColumnId="ITEM_UID" sortDirection="ASC"   >
            <grid:column_txt   id="ITEM_CLASS_PATH"        name="자재분류"              align="left"       width="200"    />
            <grid:column_txt   id="MATERIAL_TYPE_NAME"     name="자재유형"             align="left"        width="110"    />
            <grid:column_txt   id="ASSET_CLASS_NAME"       name="자산클래스"            align="left"     width="120"    />
            <grid:column_txt   id="ITEM_CODE"              name="자재코드"              align="center"     width="120"    />
            <grid:column_txt   id="ITEM_NAME"              name="자재명"                align="left"       width="200"    />
            <grid:column_txt   id="ITEM_SPEC"              name="규격/사양"             align="left"       width="300"    />
            <grid:column_txt   id="QUANTITY_UNIT_NAME"     name="기본단위"              align="center"     width="070"    />
            <grid:column_txt   id="MATERIAL_TYPE_CODE"     name="자재유형코드"           align="center"     width="090"    />
            <grid:column_txt   id="ITEM_GROUP_NAME"        name="자재그룹"              align="center"     width="090"    />
            <grid:column_txt   id="PURCHASE_GROUP_NAME"    name="구매그룹"              align="center"     width="100"    />
            <grid:column_txt   id="CP_ITEM_FLAG"           name="연단가자재여부"         align="center"     width="100"    />

            <grid:hidden        id="CLIENT_CODE"            columnName="CLIENT_CODE"            />
            <grid:hidden        id="COMPANY_CODE"           columnName="COMPANY_CODE"           />
            <grid:hidden        id="ITEM_UID"               columnName="ITEM_UID"     sortColumn="ITEM_UID"/>
            <grid:hidden        id="ITEM_CLASS_UID"         columnName="ITEM_CLASS_UID"         />
            <grid:hidden        id="ITEM_CLASS_CODE"        columnName="ITEM_CLASS_CODE"        />
            <grid:hidden        id="ITEM_CLASS_NAME"        columnName="ITEM_CLASS_NAME"        />
            <grid:hidden        id="ASSET_CLASS_CODE"       columnName="ASSET_CLASS_CODE"       />
            <grid:hidden        id="ASSET_EACH_FLAG"        columnName="ASSET_EACH_FLAG"        />

            <grid:hidden        id="MIN_QUANTITY"           columnName="MIN_QUANTITY"           />
            <grid:hidden        id="ORIGIN_CODE"            columnName="ORIGIN_CODE"            />
            <grid:hidden        id="SOURCING_USER_ID"       columnName="SOURCING_USER_ID"       />
            <grid:hidden        id="SOURCING_USER_NAME"     columnName="SOURCING_USER_NAME"     />
            <grid:hidden        id="SUPPLIER_CODE"          columnName="SUPPLIER_CODE"          />
            <grid:hidden        id="SUPPLIER_NAME"          columnName="SUPPLIER_NAME"          />
<%--            <grid:hidden        id="MATERIAL_TYPE_CODE"     columnName="MATERIAL_TYPE_CODE"     />--%>
            <grid:hidden        id="ITEM_GROUP_CODE"        columnName="ITEM_GROUP_CODE"        />
            <grid:hidden        id="PURCHASE_GROUP_CODE"    columnName="PURCHASE_GROUP_CODE"    />
            <grid:hidden        id="CURRENCY_CODE"          columnName="CURRENCY_CODE"          />
            <grid:hidden        id="PLANT_CODE"             columnName="PLANT_CODE"             />
            <grid:hidden        id="PLANT_NAME"             columnName="PLANT_NAME"             />

            <grid:hidden        id="ITEM_INGREDIENT"        columnName="ITEM_INGREDIENT"        />
            <grid:hidden        id="PACKING_UNIT_NAME"      columnName="PACKING_UNIT_NAME"      />
            <grid:hidden        id="PACKING_QUANTITY"       columnName="PACKING_QUANTITY"       />
            <grid:hidden        id="QUANTITY_UNIT"          columnName="QUANTITY_UNIT"          />

            <grid:hidden        id="LEAD_TIME"              columnName="LEAD_TIME"         />   <%--입고소요기간--%>
            <grid:hidden        id="W_LEAD_TIME"            columnName="W_LEAD_TIME"       />   <%--입고소요기간 (워킹데이 계산)--%>
        </grid:grid>
    </view:view_grid>

</view:view>

<script>

    function initPage(){

        const purchaseGroupCode = '${_user.addInfo.PURCHASE_GROUP_CODE}';

        if(purchaseGroupCode != ""){
            $("select[name='CODE_ITEM']").val(purchaseGroupCode);
        }


        $.grid(0).onCellDblClicked = function (grid, clickData) {

            try{
                let data = [];
                let closeFlag = true;
                if('${MULTI_SELECT}' == 'Y' ){
                    data.push(grid.getJsonRow(clickData.itemIndex));
                    closeFlag = false;
                } else {
                    data = grid.getJsonRow(clickData.itemIndex);
                }

                let result = true;
                try{
                    result = doBeforeLovSetValue(gridObject, data);
                }catch(e){void 0}

                if(result){

                    // 2023.08.17(PYB), 발행/구독 로직 추가
                    var createTop = parent._modalWindow.getTopmostWindow(true).createTop;
                    if(createTop){
                        top.publisher.publish($("input[name='LOV_PARAMETER_INF_ID']").val(), data);
                    }else{
                        parent.lovSetValueCallBack(data, $("input[name='LOV_PARAMETER_INF_ID']").val());
                    }

                    if(closeFlag){
                        closeModalWindow();
                    }

                }
            }catch(e){
                console.dir(e.stack);
            }
        }

    }


    //Lov CallBack처리
    function customLovSetValueCallBack(data, lovParameterInfId){
        if(lovParameterInfId == 'ITEM_CLASS_CODE'){
            $("input[name='LOV_KEYWORD']").val(data['ITEM_CLASS_CODE']);
            $("input[name='LOV_KEYWORD_DISPLAY']").val(data['ITEM_CLASS_NAME']);
        }

    }

    //Lov clearCallBack처리
    function lovClearCallBack(lovParameterInfId){

        if(lovParameterInfId == 'ITEM_CLASS_CODE'){
            $("input[name='LOV_KEYWORD']").val('');
            $("input[name='LOV_KEYWORD_DISPLAY']").val('');
        }

    }


    function changeClassCode(level) {
        const dataUrl = "/srm/cm/lov/LOV_ITEM/GET_ITEM_CLASS_SELECT_BOX";

        const clientCode = $("input[name='CLIENT_CODE']").val();
        const l1Code = $("select[name='SO_L1_ITEM_CLASS_CODE']").val();
        const l2Code = $("select[name='SO_L2_ITEM_CLASS_CODE']").val();

        const level2params = "CLIENT_CODE=" + clientCode + "&CLASS_LEVEL=2&PARENT_CLASS_CODE=" + l1Code;
        const level3params = "CLIENT_CODE=" + clientCode + "&CLASS_LEVEL=3&PARENT_CLASS_CODE=" + l2Code;

        const initSelectBox = (params, target, parentVal) => {
            const box = new SelectBox(dataUrl, params, target, null, null);
            if (!box) {
                return;
            }
            parentVal ? box.init() : box.default();
        };

        if (level === 3) {
            doSearch();
        } else if (level === 2) {
            initSelectBox(level3params, $("select[name='SO_L3_ITEM_CLASS_CODE']"), l2Code);
        } else if (level === 1) {
            initSelectBox(level2params, $("select[name='SO_L2_ITEM_CLASS_CODE']"), l1Code);
            const level3Box = new SelectBox(dataUrl, level3params, $("select[name='SO_L3_ITEM_CLASS_CODE']"), null, null);
            if (level3Box) level3Box.default();
        }
    }



    function onBeforeSearch(gridNum){

        var selectors = [
            "select[name='SO_L3_ITEM_CLASS_CODE']",
            "select[name='SO_L2_ITEM_CLASS_CODE']",
            "select[name='SO_L1_ITEM_CLASS_CODE']"
        ];

        var paramValue = selectors.map(function(sel) { return $(sel).val(); }).find(function(val) { return val !== ''; }) || '';

        $("input[name='PARAM_ITEM_CLASS_CODE']").val(paramValue);

        return true;
    }


</script>