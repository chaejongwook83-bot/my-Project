<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>


<view:view id="LOV_ITEM_REPRESENTATIVE" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="대표상품코드">
        <view:buttons>
            <view:button id="CLOSE"  label="닫 기" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="LOV_ITEM_REPRESENTATIVE">
        <search:so cols="2" rows="1"  fixedRows="0">

            <search:so_keyword     row="1" col="1"  selectedListItemId="2"  keyword="" >
                <search:so_keyword_item id="1" label="상품명"      value="1" columnName="ITEM_NAME" />
            </search:so_keyword>

            <search:so_keyword     row="1" col="2"  selectedListItemId="2"  keyword="" >
                <search:so_keyword_item id="1" label="상품코드"      value="1" columnName="ITEM_CODE" />
            </search:so_keyword>
            <search:so_paging rowsPerPage="500" />

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="LOV_ITEM_REPRESENTATIVE">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="LOV_ITEM_REPRESENTATIVE">
        <grid:grid     showCheck="true"  sortColumnId="ITEM_UID" sortDirection="ASC"   >
            <grid:column_txt    id="ITEM_CODE"				name="상품코드"		width="100" align="left"   />
            <grid:column_txt    id="ITEM_NAME"				name="상품명"       width="250" align="left"   />
            <grid:column_txt    id="ITEM_DESCRIPTION"		name="규격"			width="300" align="left"   />
            
            <%-- 소싱그룹 개발 후 추가--%>
            <%-- <grid:column_txt    id="SCG_GROUP_NAME"         name="품목분류"     width="240" align="left"   /> --%>

            <grid:hidden        id="CLIENT_CODE"		columnName="CLIENT_CODE"            />
            <grid:hidden        id="COMPANY_CODE"		columnName="COMPANY_CODE"           />
            <grid:hidden        id="ITEM_UID"			columnName="ITEM_UID"	sortColumn="ITEM_UID"/>
            

        </grid:grid>
    </view:view_grid>

</view:view>

<script>

    $(document).ready(function() {
        InitRealGrids();
        resize();
        createHiddenParameter();
        doSearch();
        $("input[name='KEYWORD_KEYWORD']").focus();
    });


</script>