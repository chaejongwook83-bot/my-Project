<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>

<input type="hidden" name="TABLE_NAME" value="${TABLE_NAME}"/>
<input type="hidden" name="RX_H_UID" value="${RX_H_UID}"/>
<input type="hidden" name="RX_D3_UID" value="${RX_D3_UID}"/>
<input type="hidden" name="RX_L1_UID" value="${RX_L1_UID}"/>
<input type="hidden" name="CT_H_UID" value="${CT_H_UID}"/>
<input type="hidden" name="CT_L2_UID" value="${CT_L2_UID}"/>
<input type="hidden" name="EX_H_UID" value="${EX_H_UID}"/>

<view:view id="LOV_TABLE_HISTORY" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="작업수행내역">
        <view:buttons>
            <view:button id="CLOSE"   label="Close" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="TABLE_HISTORY">
        <search:so cols="3" rows="1"  fixedRows="0">
            <search:so_paging rowsPerPage="500" />
        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="TABLE_HISTORY">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="TABLE_HISTORY">
        <grid:grid     showCheck="false"  sortColumnId="R_NUM" sortDirection="DESC"   >
            <grid:column_num  id="R_NUM"        name="차수"        width="060" align="center" sortColumn="R_NUM" />
            <grid:column_txt  id="ACTION_NAME"  name="수행작업"    width="250" align="left" />
            <grid:column_txt  id="REG_NAME"     name="작성자"      width="100" align="center" />
            <grid:column_date id="REG_DATE"     name="작성일"      width="150" align="center" formatter="<%=FMTType.DATEMIN %>"/>
        </grid:grid>
    </view:view_grid>

</view:view>

<script>

</script>