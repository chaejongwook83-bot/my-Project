<%@ page contentType="text/html; charset=UTF-8" %>


<script src="${pageContext.request.contextPath}/ext/jquery/jquery.time-to.js"></script>
<script src="${pageContext.request.contextPath}/ext/jquery/jquery.tmpl.min.js"></script>

<link href="${pageContext.request.contextPath}/ext/jquery/timeTo.css" rel="stylesheet">

<%--
  ~  Copyrightⓒ 2022. (주)매트릭스투비 All rights reserved.
  ~
  --%>
<style>
.statusContainer {
    width: 100%;
    border-color: #dce7f7 #C2D5DC #9db4d6 #dce7f7;
    float: left;
    text-align: left;
    line-height: 27px;
    background-color: #4C4C4C;
    /*background-color: rgba(96, 180, 234, 0.2);*/
    border-radius: 3px;
    margin: 5px;
}

#cur_ohlv {
    position: relative;
    overflow: hidden;
    display: inline;
    /*width: 100%;*/
    /*min-width: 924px;*/
    height: 58px;
    font-size: 14px;
    font-family:"NanumGothic", sans-serif;
    float: left;
}

#cur_ohlv dl {
    float: left;
    box-sizing: border-box;
    margin: 0;
}

#cur_ohlv dt, #cur_ohlv dd {
    box-sizing: border-box;
    margin: 0;
}

#cur_ohlv .last {
    border-right: 1px solid #d9d9d9;
}

/* 남은시간, 시작가, 최저가 */
#cup {
    position: relative;
    width: 75.8%;
    min-width: 630px;
    background: #fefcfb url(images/dash_board/bg_line.png) repeat-x 0 0px;
}

#cup dt, #cup dd {
    float: left;
    height:58px;
    line-height: 58px;
}

#cup dd span {
    color: #2b7ec3;
    font-size: 12px;
}



#cur_close {
    position:absolute;
    left:12%;
    top:34%;
    width:230px;
    display:inline-block;
    text-align: center;
/*     background: url(images/dash_board/bg_date.png) repeat-x right 0px; */
    font-size: 26px;
    font-weight: bold;
    color: #ffffff;
}
@media(max-width:1280px){
    #cur_close {
        position:relative;
        margin:0 auto;
        left:auto;
        top:56%;
    }
    .biding-count .count_time b {top:7%;left:20px;}
}
@media(max-width:941px){
    #cur_close {
        position:relative;
        margin:0 auto;
        left:auto;
        top:30%;
    }
    .biding-count .count_time b {top:3%;left:20px;}
}
@media(max-width:750px){
    #cur_close {
        position:relative;
        margin:0 auto;
        left:auto;
        top:15%;
    }
    .biding-count .count_time b {position:relative;top:3%;left:auto;margin:0 auto;display:block;}
}

#updown_title, #percent_title, #updown, #percent {
    top: 10px;
    text-align: left;
    font-weight: 400;
}

#updown_title, #percent_title {
    text-align: center;
    width: 8%;
}

#updown, #percent {
    font-size: 18px;
    text-align: center;
    font-weight: bold;
    width: 20%;
    line-height: 56px !important;
}

#percent_title, #percent {
    top: 35px;
}

#percent {
    color: #d90e00;
}

.price_border {
    border-top: 1px solid #6098cb;
    border-bottom: 1px solid #6098cb;
}

.price_border_top {
    border-top: 1px solid #6098cb;
}

.price_border_bottom {
    border-bottom: 1px solid #6098cb;
}

/* 나의순위 투찰가능회수 */
#ohlv {
    position: relative;
    display: inline-block;
    width: 24%;
    height: 58px;
    min-width: 200px;
    box-sizing: border-box;
    margin: 0;
    background: #fefcfb url(images/dash_board/bg_line.png) repeat-x 0 0px;
}

#cur_ohlv .radius {
    border-radius: 0px 3px 3px 0px;
    /*border-top: 1px solid #6098cb;*/
    border-right: 1px solid #6098cb;
    /*border-bottom: 1px solid #6098cb;*/
}

#ohlv dt, #ohlv dd {
    position: absolute;
    text-align: center;
    width: 50%;
    line-height: 28px;
}

#ohlv .line {
    background: url(images/dash_board/line_dot.gif) no-repeat left 0;
}

#ohlv dd {
    top: 26px;
    height: 31px;
    color: #2b7ec3;
    font-weight: bold;
    font-size: 20px;
}

#ohlv dd span {
    color: #2b7ec3;
    font-size: 12px;
}

#high_title, #high {
    left: 49%;
}
</style>

<script>

$( document ).ready(function() {        
    
    resizeTimer();
    resizeContent();
    
    if('${STATUS_PROGRESS}' != ''){
        $("div[name='statusProcess']").css("display","");
    }
    
});

$('#cooldownTimer').on('load', function () {
    $(this).width($(this).contents().width());
});

$( window ).resize(function() {
    //resizeTimer();
    resizeContent();
});

function resizeTimer(){
     //var firstBtn = $(".grid_header_btn").first().offset().left;                  
    // if(firstBtn){     
        //var pos = firstBtn - $("#timerContainer").outerWidth()-38;     
        //$("#timerContainer").css("left",pos).css("display",""); 
        $("#cooldownTimer").css("display","");
     //}
}


function resizeContent(){
    
     var paddingLeft  = 0;     
     try{
         paddingLeft = Number($("#Container_entry").css("padding-left").replace("px",""));
     }catch(e){void 0}
     
     
     var paddingRight = 0     
     try{
         paddingRight = Number($("#Container_entry").css("padding-right").replace("px",""));
     }catch(e){void 0}
     
     
     var disWidth = $(window).width()-paddingLeft-paddingRight;     
     // $("#cur_ohlv").width(disWidth);     
     // if(disWidth < 924){
     //     $("#cur_ohlv").css("min-width","924px");
     // }
     
}

</script>
<div class="biding-count">
    <ul>
        <timer id="cooldownTimerCT" style="display:none;">
        
                    <li class="count_time">
                        <b id="close_title" class="ico ico-fob-watch"><script>mwfMsg.message('CO_0142')</script></b>
                       
                            <div id="cur_close">
                                <iframe id="cooldownTimer"   scrolling="no" style="position:relative;top:0px;float:left;overflow: hidden;height: 0px;width:0px;visibility: hidden;padding: 0px;margin: 0px 5px 0px 10px;"  src="${pageContext.request.contextPath}/srm/cm/common/coolDown"></iframe>
                            </div>
                    </li>
        </timer>                       
        
        <dashBoard id="status_board">
        </dashBoard>            
    
	    <dashBoard id="status_board_ra">
	    </dashBoard>   
    
    </ul>
         
</div>


<script id="RQ_BOARD" type="text/x-jquery-tmpl">
<li class="count_price">
{{if total_amount != ""}}
	<div class="price_01"><b>{{html mwfMsg.message('CO_0166')}}</b><span>{{html converAmount(total_amount, amountUnitName)}}(VAT별도)</span></div>
{{/if}}
{{if total_amount == ""}}
	<div class="price_01"><b>{{html mwfMsg.message('CO_0166')}}</b><span>--- {{= amountUnitName}}</span></div>
{{/if}}

{{if choice_amount != ""}}
    <%--<div id="percent_title">${CO_0143}</div><div id="percent" >{{html converAmount(choice_amount, amountUnitName)}}</div>--%>
{{/if}}
{{if choice_amount == ""}}
    <%--<div id="percent_title">${CO_0143}</div><div id="percent" style="color:black;">-</div>--%>
{{/if}}
</li>
</script>

<script id="RP_BOARD" type="text/x-jquery-tmpl">
{{if total_amount != ""}}
    <dt id="percent_title">${CO_0166}</td><dd id="percent" style="color:blue;">{{html converAmount(total_amount, amountUnitName)}}</dd>
{{/if}}
{{if total_amount == ""}}
    <dt id="percent_title">${CO_0166}</td><dd id="percent" style="color:black;">--- {{= amountUnitName}}</dd>
{{/if}}

{{if choice_amount != ""}}
    <%--<dt id="percent_title">${CO_0143}</td><dd id="percent" >{{html converAmount(choice_amount, amountUnitName)}}</dd>--%>
{{/if}}
{{if choice_amount == ""}}
    <%--<dt id="percent_title">${CO_0143}</td><dd id="percent" style="color:black;">-</dd>--%>
{{/if}}
</script>

<script id="BD_BOARD" type="text/x-jquery-tmpl">
<li class="count_price">
{{if total_amount != ""}}
	<div class="price_01"><b>{{html mwfMsg.message('CO_0166')}}</b><span>{{html converAmount(total_amount, amountUnitName)}}(VAT별도)</span></div>
{{/if}}
{{if total_amount == ""}}
	<div class="price_01"><b>{{html mwfMsg.message('CO_0166')}}</b><span>--- {{= amountUnitName}}</span></div>
{{/if}}

{{if choice_amount != ""}}
    <dt id="percent_title">${CO_0143}</td><dd id="percent" >{{html converAmount(choice_amount, amountUnitName)}}</dd>
{{/if}}
{{if choice_amount == ""}}
    <dt id="percent_title">${CO_0143}</td><dd id="percent" style="color:black;">-</dd>
{{/if}}
</li>
</script>

<script id="RA_BOARD" type="text/x-jquery-tmpl">
<li class="count_lanking">
{{if CHANGE_RANK_FLAG == "Y"}}
    <div class="lanking_01"><b>{{html mwfMsg.message('CO_0144') }}</b>
	    <span>
        {{if AMOUNT_RANK == ""}}
           ---
        {{else}}
            {{= AMOUNT_RANK}}<em> {{html mwfMsg.message('CO_0156')}}</em>
        {{/if}}
        </span>
    </div>
{{else}}
	<div class="lanking_01"><b>{{html mwfMsg.message('CO_0144') }}</b>
	    <span>
        {{if AMOUNT_RANK == ""}}
           ---
        {{else}}
            {{= AMOUNT_RANK}}<em> {{html mwfMsg.message('CO_0156')}}</em>
        {{/if}}
        </span>
    </div>

{{/if}}

{{if REMAIN_CNT > 0 && BIDDING_COUNT_FLAG == "Y" && CLOSE_YN == "N" }}
	<div class="lanking_02"><b>{{html mwfMsg.message('CO_0147') }} </b><span class="text-primary">{{= REMAIN_CNT}} <em>{{html mwfMsg.message('CO_0157')}}</em></span></div>
{{/if}}

{{if   CLOSE_YN == "N"  && BIDDING_COUNT_FLAG == "N" }}
	<div class="lanking_02"><b>{{html mwfMsg.message('CO_0147') }} </b><span class="text-primary">{{html mwfMsg.message('CO_0169')}}</span></div>
{{/if}}

{{if (REMAIN_CNT == 0 && BIDDING_COUNT_FLAG == "Y") || CLOSE_YN == "Y"   }}
	<div class="lanking_02"><b>{{html mwfMsg.message('CO_0147') }} </b><span class="text-primary redColor">{{html mwfMsg.message('CO_0148')}}</span></div>
{{/if}}

</li>

</script>

<script id="RA_BOARD_AMT" type="text/x-jquery-tmpl">
<li class="count_price">
	<div class="price_01"><b>{{html mwfMsg.message('CO_0155')}}</b><span>{{html converAmount(MY_AMOUNT)}}</span></div>
{{if PREV_AMOUNT != ""}}

{{/if}}

{{if CHANGE_RANK_FLAG == "Y"}}
	 <div class="price_02"><b>{{html getRaContent('LABEL', AUCTION_TYPE_CODE)}}</b><span>{{html converAmount(total_amount, amountUnitName)}}</span></div>
{{else}}
     <div class="price_02"><b>{{html getRaContent('LABEL', AUCTION_TYPE_CODE)}}</b><span>{{html converAmount(total_amount, amountUnitName)}}</span></div>
{{/if}}
</li>
</script>


<script>

function converAmount(amount, amountUnit, flag){
    var flag = flag == null ? "LABEL" : "IMG";
    
    var amt = top.getNumberUnMask(amount+"");
    
    // var label = flag == "LABEL" ? "<span style='font-size:9px;'>"+mwfMsg.message("CO_0160")+"</span>" : mwfMsg.message("CO_0160");
    var label = flag == "LABEL" ?  mwfMsg.message("CO_0160") :  mwfMsg.message("CO_0160");
    
    //금액이 1억보다 클 경우 100만 단위로 절삭
    // if(amt >= 100000000){
    //     var digits = Math.pow(10, 2);
    //     amt = String(Math.floor((amt/1000000)*digits)/digits);
    //     amt = String(getNumberMask(amt,2))+" "+label;
    // }else{
    //     amt = getNumberMask(amt) + " 원";
    // }
    
    amountUnit = amountUnit || 'KRW' === 'KRW' ? mwfMsg.message('CO_0223') : amountUnit;
    amt = top.getNumberMask(amt, 'amt', null, null, null, amountUnit === '원' ? 'KRW' : amountUnit);
    amt = (amt == "" ? "---" : amt) + "   " +amountUnit;

    return amt;
}

function getRaContent(type, auctionTypeCode){
    var html = "";
    
    if(type == "IMG"){

        if(auctionTypeCode == "F"){
            html = '<img src="/'+_CONTEXT_NAME+'/images/dash_board/price_up.png" width="18" height="18" />';
        }else if(auctionTypeCode == "R"){
            html = '<img src="/'+_CONTEXT_NAME+'/images/dash_board/price_down.png" width="18" height="18" />';
        }
        
    }else if(type == "LABEL"){
        if(auctionTypeCode == "F"){
             html = mwfMsg.message("CO_0171");
        }else if(auctionTypeCode == "R"){
             html = mwfMsg.message("CO_0145");
        }
    }
    
    
    return html;
    
}



/**
 * 마감시간 까지 카운트 한다.
 * @param dueDate   마감시간
 * @param callback  callback함수
 */
function TimerManager(type, dueDate, callback){
    
    this.type     = type;
    this.dueDate  = dueDate;
    this.callback = callback;
    
    this.draw = function (){
        
        
        //상태 Display
        this.displayStatus();
        
        var ajaxDate = invokeAjax('/srm/cm/common/GET_CURR_DATE');
        var date;
        if(ajaxDate.success){
        	date = ajaxDate.attrs['CURR_DATE'];
        } else {
        	return false;
        }
        
        //var date = '20220609110131';  //invokeAjax('FILE_ID=action.AJAX.AJAX_COMMON&ACTION_ID=CURR_DATE').split("|")[0];
        var currDate = new Date(
            parseInt(date.substring(0,4), 10),       // 연도
            parseInt(date.substring(4,6), 10) - 1,   // 월 (0부터 시작)
            parseInt(date.substring(6,8), 10),       // 일
            parseInt(date.substring(8,10), 10),      // 시
            parseInt(date.substring(10,12), 10),     // 분
            parseInt(date.substring(12,14), 10),     // 초
            0
        );


        var close_status = true;
        
        //마감상태 체크
        $("input[name='CLOSE_YN']").each(function(){
            if($(this).val() == "Y"){
                close_status = false;
            }
        });
        
        var dueDateType = false;
        if (typeof dueDate === 'object' && dueDate instanceof Date) {
            dueDateType = true;
        }
        
        var currDateType = false;
        if (typeof currDate === 'object' && currDate instanceof Date) {
            currDateType = true;
        }
        
        //마감시간이 현재 시간보다 크고 진행 중인 경우
        if(dueDate > currDate && close_status && dueDateType && currDateType){
        
            $('#cooldownTimer').css("width",'100%');
            $('#cooldownTimer').css("height",'27px');
            $('#cooldownTimer').css("visibility",'visible');
            $("#close_title").html(mwfMsg.message('CO_0142'));
            $('#cooldownTimerCT').css("display",'');

            var dif      = dueDate.getTime() - currDate.getTime();
            var time   = Math.abs(dif / 1000);
            
            $('#cooldownTimer').contents().find('#countdown').timeTo({
                seconds:time,
                displayCaptions: false,
                fontSize: 18,
                captionSize: 11,
                countdownAlertLimit:1800
            },callback);

            //TODO 경매타이머 초 화면 임시제거 복구
            const secondElms = $('#cooldownTimer').contents().find('#countdown > :nth-last-child(-n+3)');
            for (const secondElm of secondElms) {
                // secondElm.style.display = 'none';
            }
            
        }else{
            
            //종료 시 콜백함수 호출
            //callback.call(this);
            $("#close_title").html(mwfMsg.message('CO_0158'));
            $('#cooldownTimerCT').css("display",'');
            $("#cur_close").remove();
            
            
        }
        
        return true;
    }
    
    
    this.displayStatus = function(){
        
        
        var data           = null;
        var tmpContainerId = "status_board";
        var status = $("input[name='STATUS']").val();
        
        if(this.type == "RQ"){
         
        	data = {};
            data.choice_amount = '';
            
            data.total_amount  = $("input[name='TOTAL_AMOUNT_LOCAL']").val();
            let totalAmountUnit = $("input[name='TOTAL_AMOUNT_UNIT']").val() || 'KRW';
            data.amountUnitName = totalAmountUnit === 'KRW' ? mwfMsg.message('CO_0223') : totalAmountUnit;
            /* 무조건 total_amount나오도록 변경
            if(status == "CFM" || status == "CFM"){
                data.total_amount  = $("input[name='TOTAL_AMOUNT']").val();
            }else{
                data.total_amount = "";
            }
            */
           // $("#cup").attr("style","border-right:1px solid #6098cb;border-radius:0px 3px 3px 0px;width:100%");
           
        }else if(this.type == "BD"){
         
        	data = {};
            data.choice_amount = '';
            
            data.total_amount  = $("input[name='TOTAL_AMOUNT_LOCAL']").val();
            let totalAmountUnit = $("input[name='TOTAL_AMOUNT_UNIT']").val() || 'KRW';
            data.amountUnitName = totalAmountUnit === 'KRW' ? mwfMsg.message('CO_0223') : totalAmountUnit;
            /*
            if(status == "CFM" || status == "CFM"){
                data.total_amount  = $("input[name='TOTAL_AMOUNT']").val();
            }else{
                data.total_amount = "";
            }      
            */
            //$("#cup").attr("style","border-right:1px solid #6098cb;border-radius:0px 3px 3px 0px;width:100%");
            
        }else if(this.type == "RA"){
            //status 라벨은 init() 함수에서 수행
            tmpContainerId = tmpContainerId + "_ra";
            $("#cup").attr("style","border-right:1px solid #6098cb;border-radius:0px 3px 3px 0px;width:100%");
        }

        if(data != null){
            $("#status_board").css("display","");            
            $("#status_board").html("");
            $("#" + this.type + "_BOARD").tmpl(data).appendTo("#"+tmpContainerId);
        }
        
    }
        
    this.test = function (){                            
        $('#cooldownTimer').contents().find('#countdown').timeTo({seconds:10},callback);                                   
    }    
                        
}



</script>