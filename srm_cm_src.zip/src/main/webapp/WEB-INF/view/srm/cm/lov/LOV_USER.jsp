<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp" %>


<view:view id="LOV_USER" type="<%= ViewType.LOV %>" session="<%=session%>" model="<%=request%>">

    <view:title name="사용자">
        <view:buttons>
            <view:button id="CLOSE" label="닫기"/>
        </view:buttons>
    </view:title>

    <view:view_so groupId="LOV_USER">
        <search:so cols="2" rows="1" fixedRows="0">

            <search:so_keyword row="1" col="1" selectedListItemId="1" keyword="">
                <search:so_keyword_item id="1" label="사용자ID" value="1" columnName="USER_ID"/>
            </search:so_keyword>

            <search:so_keyword row="1" col="2" selectedListItemId="1" keyword="">
                <search:so_keyword_item id="1" label="사용자명" value="1" columnName="FN_DECRYPT(SU.USER_NAME, 'AES')"/>
            </search:so_keyword>

            <search:so_paging rowsPerPage="500"/>

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="LOV_USER">
        <toolbar:toolbar showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH" label="조 회" href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="LOV_USER">
        <grid:grid sortColumnId="DEPT_NAME|LOGIN_ID" sortDirection="ASC|ASC">
            <grid:column_txt id="LOGIN_ID"          name="사번"               width="100"   align="center"   sortColumn="LOGIN_ID"/>
            <grid:column_txt id="USER_NAME"         name="사용자명"           width="100"   align="center"   />
            <grid:column_txt id="DEPT_CODE"         name="부서 코드"           width="100"   align="center" />
            <grid:column_txt id="DEPT_NAME"         name="부서"               width="120"   align="center"   sortColumn="DEPT_NAME"/>
            <grid:column_txt id="DUTY_NAME"         name="직책"               width="100"   align="center"   />
            <grid:column_txt id="COST_CENTER_CODE"  name="코스트센터 코드"    width="120"   align="center"   />
            <grid:column_txt id="COST_CENTER_NAME"  name="코스트센터 명"      width="120"   align="center"   />
            <grid:column_txt id="TELEPHONE_NO"      name="전화번호"           width="110"   align="center"   />
            <grid:column_txt id="MOBILE_NO"         name="모바일"             width="110"   align="center"   />
            <grid:column_txt id="EMAIL"             name="메일"               width="180"   align="center"   />

            <grid:hidden id="COMPANY_CODE"  columnName="COMPANY_CODE"   />
            <grid:hidden id="ORG_PATH"      columnName="ORG_PATH"       />
            <grid:hidden id="ORG_NAME"      columnName="ORG_NAME"       />
            <grid:hidden id="ORG_CODE"      columnName="ORG_CODE"       />
            <grid:hidden id="USER_ID"       columnName="USER_ID"        /> <%-- 100/100/사용자ID --%>
            <grid:hidden id="USER_UID"      columnName="USER_UID"       />
            <grid:hidden id="DUTY_CODE"     columnName="DUTY_CODE"      />

        </grid:grid>
    </view:view_grid>

</view:view>

<script>

    function onBeforeSearch(gridNum){
        let trimmed = $("input[name='KEYWORD_KEYWORD2']").val().trim();
        // 값이 있을 때만 검사
        if (trimmed.length > 0) {
            if (trimmed.length < 2) {
                mwfMsg.showMessage("E-0078"); // E-0078  사용자명은 2글자 이상 입력하셔야 합니다.
                return false;
            }
        }
        return true;
    }

</script>