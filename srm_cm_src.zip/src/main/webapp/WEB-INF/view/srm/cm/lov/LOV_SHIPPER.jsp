<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>


<view:view id="LOV_SHIPPER" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="화주사">
        <view:buttons>
            <view:button id="CLOSE"   label="Close" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="SHIPPER">
        <search:so cols="3" rows="1"  fixedRows="0">

            <search:so_keyword     row="1" col="1"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="2" label="업체명" value="1" columnName="CUSTOMER_NAME"  />
            </search:so_keyword>

            <search:so_keyword     row="1" col="2"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="업체코드" value="1" columnName="CUSTOMER_CODE" />
            </search:so_keyword>

            <search:so_keyword     row="1" col="3"  selectedListItemId="1"  multi=""  keyword="">
                <search:so_keyword_item id="1" label="사업자등록번호"   value="1" columnName="BUSINESS_NUMBER" />
            </search:so_keyword>

            <search:so_paging rowsPerPage="500" />

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="SHIPPER">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href="doSearch()"/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="SHIPPER">
        <grid:grid     showCheck="true"  sortColumnId="CUSTOMER_CODE" sortDirection="ASC"   >
            <grid:column_txt    id="CUSTOMER_CODE"          name="화주사 코드"       width="120" align="center" sortColumn="CUSTOMER_CODE" />
            <grid:column_txt    id="CUSTOMER_NAME"          name="화주사명"          width="400" align="left" />
            <grid:column_txt    id="BUSINESS_NUMBER"        name="사업자등록번호"    width="110" align="left"   />
            <grid:column_txt    id="CEO_NAME"               name="대표이사"          width="080" align="left"   />
            <grid:column_txt    id="ADDRESS"                name="주소"             width="400" align="left" />

            <grid:hidden        id="CLIENT_CODE"  columnName="CLIENT_CODE"  />
        </grid:grid>
    </view:view_grid>

</view:view>

<script>
    function doSearch() {
        if ($.txt("KEYWORD_KEYWORD").val() == "" && $.txt("KEYWORD_KEYWORD2").val() == "" && $.txt("KEYWORD_KEYWORD3").val() == "") {
            mwfMsg.showMessage("CO_1015"); // 검색 조건 중 하나는 반드시 입력하셔야 조회  하실수 있습니다.
            $("input[name='KEYWORD_KEYWORD']").focus();
            return;
        }
        doGridExecute(0,_REQ_URL, 'SEARCH');
    }
</script>

