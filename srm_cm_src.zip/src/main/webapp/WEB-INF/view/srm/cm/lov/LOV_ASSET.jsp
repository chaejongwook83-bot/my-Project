<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>


<view:view id="LOV_ASSET" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="자산">
        <view:buttons>
            <view:button id="CLOSE"  label="닫 기" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="LOV_ASSET">
        <search:so cols="2" rows="1"  fixedRows="0">

            <search:so_keyword     row="1" col="1"  selectedListItemId="2"  keyword="" >
                <search:so_keyword_item id="1" label="자산번호"      value="1" columnName="ANLN1" />
            </search:so_keyword>

            <search:so_keyword     row="1" col="2"  selectedListItemId="2"  keyword="" >
                <search:so_keyword_item id="1" label="자산내역"      value="1" columnName="TXT50" />
            </search:so_keyword>
            <search:so_paging rowsPerPage="500" />

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="LOV_ASSET">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="true" showGridSetting="false">
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="LOV_ASSET">
        <grid:grid     showCheck="true"  sortColumnId="ANLN1" sortDirection="ASC"   >
            <grid:column_txt    id="ANLN1"                name="자산번호"       width="150" align="center" sortColumn="ANLN1"   />
            <grid:column_txt    id="TXT50"                name="자산내역"       width="400" align="left"   />

        </grid:grid>
    </view:view_grid>

</view:view>
