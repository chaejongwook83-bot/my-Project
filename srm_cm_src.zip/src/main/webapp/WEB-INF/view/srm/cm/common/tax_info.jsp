<%@ page contentType="text/html; charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>

<!DOCTYPE html>
<html lang="kr" >

<!-- 12자리로 왼쪽 0 채우기 -->

			<!-- 12자리로 왼쪽 0 채우기 -->
<c:set var="totalAmt" value="${'000000000000'}${TOTAL_AMOUNT}" />
<c:set var="totalAmt" value="${fn:substring(totalAmt, fn:length(totalAmt)-12, fn:length(totalAmt))}" />

<c:set var="supplyAmt" value="${'000000000000'}${SUPPLY_PRICE}" />
<c:set var="supplyAmt" value="${fn:substring(supplyAmt, fn:length(supplyAmt)-12, fn:length(supplyAmt))}" />

<!-- 11자리로 왼쪽 0 채우기 -->
<c:set var="vatAmt" value="${'00000000000'}${VAT_AMOUNT}" />
<c:set var="vatAmt" value="${fn:substring(vatAmt, fn:length(vatAmt)-11, fn:length(vatAmt))}" />

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi">
    <meta name="format-detection">
    <meta name="title" property="og:title" content="">
    <meta name="images" property="og:image" content="">
    <meta name="description" property="og:description" content="">
    <meta name="keyword" content="">
    <meta name="type" property="og:type" content="article">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- IE, Chrome 아이콘 이미지 -->
    <link href="/images/favicon.ico" rel="shortcut icon" type="image/x-icon"/>
    <style type="text/css">
        /* 1. 변수 정의 (Global Variables) */
        :root {
            /* 폰트 및 텍스트 */
            --font-base: "돋움", "돋움체", "Verdana", sans-serif;
            --size-base: 9pt;
            --line-height-base: 145%;
            --color-text-main: #000000;
            --color-text-sub: #6d6d6d;

            /* 스크롤바 색상 */
            --scroll-face: #dddddd;
            --scroll-highlight: #cccccc;
            --scroll-shadow: #c8c8c8;
            --scroll-3dlight: #f5f5f5;
            --scroll-arrow: #ffffff;
            --scroll-track: #f0f0f0;

            /* 테두리 색상 */
            --border-gray: #ababab;
            --border-blue-html: #4f628a;
            --border-blue: #0000ff; /* .tdbd 클래스에서 집중적으로 사용됨 */

            /* 송장(Invoice) 관련 테마 색상 */
            --invoicer-header-text: #e10d0d;
            --invoicer-header-bg: #ffd9d9;
            --invoicer-item-text: #af5f5f;
            --invoicer-item-bg: #fff2f2;

            --invoicee-header-text: #0a57cb;
            --invoicee-header-bg: #c2d9f2;
            --invoicee-item-text: #3a77a2;
            --invoicee-item-bg: #f2f5ff;
        }

        /* 2. 기본 요소 스타일 */
        body {
            /* 스크롤바 (IE/Legacy) */
            scrollbar-face-color: var(--scroll-face);
            scrollbar-highlight-color: var(--scroll-highlight);
            scrollbar-shadow-color: var(--scroll-shadow);
            scrollbar-3dlight-color: var(--scroll-3dlight);
            scrollbar-arrow-color: var(--scroll-arrow);
            scrollbar-track-color: var(--scroll-track);
            scrollbar-darkshadow-color: var(--scroll-3dlight);

            font-size: var(--size-base);
            color: var(--color-text-sub);
            line-height: var(--line-height-base);
            font-family: var(--font-base);
        }

        a {
            text-decoration: none;
        }

        a:hover {
            color: var(--color-text-main);
        }

        td {
            font-size: var(--size-base);
            color: var(--color-text-main);
            line-height: 16px;
            font-family: var(--font-base);
        }

        td a {
            color: var(--color-text-main);
        }

        div {
            position: relative;
        }

        /* 3. 유틸리티 및 테두리 스타일 */
        .border {
            border: 1px solid var(--border-gray);
        }

        /* Tip: .tdbd_... 클래스들은 패턴이 매우 유사합니다.
           변수를 적용하여 색상 변경 시 --border-blue만 수정하면 됩니다.
        */

        /* 공통적인 속성을 한 번에 묶을 수도 있습니다 (선택 사항) */
        [class^="tdbd_"] {
            font-size: var(--size-base);
            font-family: var(--font-base);
            text-decoration: none;
            border-color: var(--border-blue-html); /* 색상 변수 적용 */
            border-style: solid;
        }

        .tdbd_red_top0_left1 {
            border-width: 0px 0px 0px 1px; /* Top Right Bottom Left */
        }

        .tdbd_red_top0_left1_right2 {
            border-width: 0px 2px 0px 1px;
        }

        .tdbd_red_top2left1 {
            border-width: 2px 0px 0px 1px;
        }

        .tdbd_red_top1left1bottom2 {
            border-width: 1px 0px 2px 1px;
        }

        .tdbd_red_top1left1right2bottom2 {
            border-width: 1px 2px 2px 1px;
        }

        .tdbd_red_top2left2bottom2 {
            border-width: 2px 0px 2px 2px;
        }

        .tdbd_red_top2left1right2 {
            border-width: 2px 2px 0px 1px;
        }

        .tdbd_red_top2left2bottom1 {
            border-width: 2px 0px 1px 2px;
        }

        .tdbd_red_top2left2right2bottom1 {
            border-width: 2px 2px 1px 2px;
        }

        .tdbd_red_top1left1bottom1 {
            border-width: 1px 0px 1px 1px;
        }

        .tdbd_red_top1left1right2bottom1 {
            border-width: 1px 2px 1px 1px;
        }

        .tdbd_red_top1left2bottom1 {
            border-width: 1px 0px 1px 2px;
        }

        .tdbd_red_top1left1 {
            border-width: 1px 0px 0px 1px;
        }

        .tdbd_red_top1left1right2 {
            border-width: 1px 2px 0px 1px;
        }

        .tdbd_red_top1left2 {
            border-width: 1px 0px 0px 2px;
        }

        .tdbd_red_top1left2bottom2 {
            border-width: 1px 0px 2px 2px;
        }

        .tdbd_red_top2left2 {
            border-width: 2px 0px 0px 2px;
        }

        /* 4. 특정 텍스트 및 헤더 스타일 */
        .bulkCd0085_textRedBold {
            font-weight: bold;
            color: red; /* 표준 색상은 그대로 둠 (필요 시 변수화) */
        }

        .invoicer-header {
            color: var(--invoicer-header-text);
            background-color: var(--invoicer-header-bg);
            font-weight: bold;
        }

        .invoicer-item {
            background-color: var(--invoicer-item-bg);
            color: var(--invoicer-item-text);
        }

        .invoicee-header {
            color: var(--invoicee-header-text);
            background-color: var(--invoicee-header-bg);
            font-weight: bold;
        }

        .invoicee-item {
            background-color: var(--invoicee-item-bg);
            color: var(--invoicee-item-text);
        }
    </style>
</head>
<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
    <TBODY>
    <TR>
        <TD>
            <TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
                <TBODY>
                <TR>
                    <TD style="PADDING-LEFT: 15px" vAlign="top" align="center">
                        <TABLE cellSpacing="0" cellPadding="0" width="650" border="0">
                            <TBODY>
                            <TR>
                                <TD class="stylefont1" vAlign="bottom" width="310" height="2">
                                    <FONT color="#0000ff"/>
                                </TD>
                                <TD class="stylefont1" vAlign="bottom" align="right" width="310" height="2">
                                    <FONT color="#0000ff"/>
                                </TD>
                                <TD width="15" height="2">&#160;</TD>
                            </TR>
                            <TR>
                                <TD colSpan="2" height="2">
                                    <TABLE cellSpacing="0" cellPadding="0" width="680" border="0">
                                        <TBODY>
                                        <TR>
                                            <TD class="tdbd_red_top2left2bottom1">
                                                <TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
                                                    <TBODY>
                                                    <TR>
                                                        <TD align="middle" width="447">
                                                            <FONT style="FONT-SIZE: 11pt; LINE-HEIGHT: 30px">
                                                                <B>
                                                                    <FONT size="4">전자 세금계산서</FONT>
                                                                </B>
                                                            </FONT>
                                                        </TD>
                                                        <TD class="tdbd_red_top0_left1" vAlign="middle" align="middle"
                                                            width="50" height="18">
                                                            승인번호
                                                        </TD>
                                                        <TD class="tdbd_red_top0_left1_right2" vAlign="middle"
                                                            align="center" height="20">
                                                            &#160;${TAX_NO}
                                                        </TD>
                                                    </TR>
                                                    </TBODY>
                                                </TABLE>
                                            </TD>
                                        </TR>
                                        </TBODY>
                                    </TABLE>
                                    <TABLE cellSpacing="0" cellPadding="1" width="680" border="0">
                                        <TBODY>
                                        <TR>
                                            <!-- 세금계산서 좌측 영역 (공급자 / Invoicer) -->
                                            <TD class="tdbd_red_top1left2bottom1 invoicer-header" align="middle" width="15" height="25" rowSpan="4">
                                                공<BR/><BR/>급<BR/><BR/>자
                                            </TD>
                                            <TD class="tdbd_red_top1left1 invoicer-item" align="middle" width="50"height="32">등록번호 </TD>
                                            <TD class="tdbd_red_top1left1" style="LETTER-SPACING: 10px" align="middle"
                                                colSpan="3" height="32">
                                                <FONT size="3">
                                                    <B>
                                                    ${SUPPLIER_BUSINESS_NUMBER}	
                                                    </B>
                                                </FONT>
                                            </TD>
                                            <!-- 세금계산서 우측 영역 (공급받는자 / Invoicee) -->
                                            <TD class="tdbd_red_top1left1bottom1 invoicee-header" align="middle" width="15" height="32"
                                                rowSpan="4">
                                                공<BR/>급<BR/>받<BR/>는<BR/>자
                                            </TD>
                                            <TD class="tdbd_red_top1left1 invoicee-item" align="middle" width="50" height="32">
                                                등록번호
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2" style="LETTER-SPACING: 10px"
                                                align="middle" colSpan="3" height="32">
                                                <FONT size="3">
                                                    <B>
                                                        ${COMPANY_BUSINESS_NUMBER}	
                                                    </B>
                                                </FONT>
                                            </TD>
                                        </TR>
                                        <TR>
                                            <!-- 세금계산서 좌측 영역 (공급자 / Invoicer) -->
                                            <TD class="tdbd_red_top1left1 invoicer-item" align="middle" width="50" height="32">
                                                상 &#160;&#160;호<BR/>(법인명)
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="104" height="32">
                                                &#160;${SUPPLIER_NAME}
                                            </TD>
                                            <TD class="tdbd_red_top1left1 invoicer-item" align="middle" width="50" height="32">
                                                성명
                                            </TD>
                                            <TD class="tdbd_red_top1left1" align="middle" width="104" height="32">
                                                ${SUPPLIER_CEO_NAME}
                                            </TD>
                                            <!-- 세금계산서 우측 영역 (공급받는자 / Invoicee) -->
                                            <TD class="tdbd_red_top1left1 invoicee-item" align="middle" width="50" height="32">
                                                상 &#160;&#160;호<BR/>(법인명)
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="104" height="32">
                                                &#160;${COMPANY_NAME}
                                            </TD>
                                            <TD class="tdbd_red_top1left1 invoicee-item" align="middle" width="50" height="32">
                                                성명
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2" align="middle" width="104" height="32">
                                                ${COMPANY_CEO_NAME}
                                            </TD>
                                        </TR>
                                        <TR>
                                            <!-- 세금계산서 좌측 영역 (공급자 / Invoicer) -->
                                            <TD class="tdbd_red_top1left1 invoicer-item" align="middle" width="50" height="32">
                                                사업장<BR/>주 &#160;&#160;소
                                            </TD>
                                            <TD class="tdbd_red_top1left1" height="32">
                                                ${SUPPLIER_ADDRESS}
                                            </TD>
                                            <TD class="tdbd_red_top1left1 invoicer-item" align="middle" width="50" height="32">
                                                종사업<br/>장번호
                                            </TD>
                                            <TD class="tdbd_red_top1left1" height="32">
                                                &#160;
                                            </TD>

                                            <!-- 세금계산서 우측 영역 (공급받는자 / Invoicee) -->
                                            <TD class="tdbd_red_top1left1 invoicee-item" align="middle" width="50" height="32">
                                                사업장<BR/>주 &#160;&#160;소
                                            </TD>
                                            <TD class="tdbd_red_top1left1" height="32">
                                                ${COMPANY_ADDRESS}
                                            </TD>
                                            <TD class="tdbd_red_top1left1 invoicee-item" align="middle" width="50" height="32">
                                                종사업<br/>장번호
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2" height="32">
                                                &#160;
                                            </TD>

                                        </TR>
                                        <TR>
                                            <!-- 세금계산서 좌측 영역 (공급자 / Invocier) -->
                                            <TD class="tdbd_red_top1left1bottom1 invoicer-item" align="middle" width="50" height="32">
                                                업 &#160;&#160;태
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" width="104" height="32">
                                                &#160;${SUPPLIER_BUSINESS_TYPE}
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1 invoicer-item" align="middle" width="50" height="32">
                                                종목
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" width="104" height="32">
                                                &#160;${SUPPLIER_BUSINESS_ITEM}
                                            </TD>
                                            <!-- 세금계산서 우측 영역 (공급받는자 / Invoicee) -->
                                            <TD class="tdbd_red_top1left1bottom1 invoicee-item" align="middle" width="50" height="32">
                                                업 &#160;&#160;태
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" width="104" height="32">
                                                &#160;
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1 invoicee-item" align="middle" width="50" height="32">
                                                종목
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2bottom1" width="104" height="32">
                                                &#160;${COMPANY_BUSINESS_ITEM}
                                            </TD>
                                        </TR>
                                        </TBODY>
                                    </TABLE>
                                    <TABLE cellSpacing="0" cellPadding="1" width="680" border="0">
                                        <TBODY>
                                        <TR vAlign="bottom" align="middle">
                                            <TD class="tdbd_red_top1left2" colSpan="3" height="20">
                                                작성일자
                                            </TD>
                                            <TD class="tdbd_red_top1left1" colSpan="12" height="20">
                                                공 &#160;급 &#160;가 &#160;액
                                            </TD>
                                            <TD class="tdbd_red_top1left1" colSpan="11" height="20">
                                                세 &#160;&#160;액
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2" width="125" height="20">
                                                수정사유
                                            </TD>
                                        </TR>
                                        <TR>
                                            <TD class="tdbd_red_top1left2" vAlign="bottom" align="middle" width="40">
                                                년
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="20">
                                                월
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="20">
                                                일
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                천
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                백
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                십
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                억
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                천
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                백
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                십
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                만
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                천
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                백
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                십
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle" width="13">
                                                일
                                            </TD>


                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                백
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                십
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                억
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                천
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                백
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                십
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                만
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                천
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                백
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                십
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" align="middle"
                                                width="13">
                                                일
                                            </TD>

                                            <TD align="center" class="tdbd_red_top1left1right2bottom1" rowSpan="2">
                                                &#160;

                                            </TD>
                                        </TR>
                                        <TR>
                                            <TD class="tdbd_red_top1left2bottom1" align="middle" width="40" height="20">
                                                &#160;${ISSUE_DATE_YYYY}
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" align="middle" width="20" height="20">
                                                &#160;${ISSUE_DATE_MM}
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" align="middle" width="20" height="20">
                                                &#160;${ISSUE_DATE_DD}
                                            </TD>
                                          <c:set var="started" value="false" />  
                                          <c:forEach var="i" begin="0" end="11">
											    <c:set var="digit" value="${fn:substring(supplyAmt,i,i+1)}" />
											    <td class="tdbd_red_top1left1bottom1" align="middle" width="13">
											      <c:choose>
											        <c:when test="${digit eq '0' and not started}">
											          &#160;
											        </c:when>
											        <c:otherwise>
											          <b><font color="#000000">${digit}</font></b>
											          <c:set var="started" value="true" />
											        </c:otherwise>
											      </c:choose>
											    </td>
										  </c:forEach>
										  
										  <c:set var="started" value="false" />  
                                          <c:forEach var="i" begin="0" end="10">
											    <c:set var="digit" value="${fn:substring(vatAmt,i,i+1)}" />
											    <td class="tdbd_red_top1left1bottom1" align="middle" width="13">
											      <c:choose>
											        <c:when test="${digit eq '0' and not started}">
											          &#160;
											        </c:when>
											        <c:otherwise>
											          <b><font color="#000000">${digit}</font></b>
											          <c:set var="started" value="true" />
											        </c:otherwise>
											      </c:choose>
											    </td>
										  </c:forEach>
                                            
                                        </TR>
                                        <TR vAlign="middle" align="middle" height="40">
                                            <TD class="tdbd_red_top1left2bottom1" colSpan="3">
                                                비 고
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2bottom1" colSpan="24" align="left">
                                                &#160;
                                            </TD>
                                        </TR>
                                        </TBODY>
                                    </TABLE>
                                    <TABLE cellSpacing="0" cellPadding="1" width="680" border="0">
                                        <TBODY>
                                        <TR vAlign="bottom" align="middle">
                                            <TD class="tdbd_red_top1left2" width="20" height="25">
                                                월
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="20" height="25">
                                                일
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="122" height="25">
                                                품 목
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="70" height="25">
                                                규 격
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="30" height="25">
                                                수 량
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="75" height="25">
                                                단 가
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="100" height="25">
                                                공급가액
                                            </TD>


                                            <TD class="tdbd_red_top1left1" width="95" height="25">
                                                세 액
                                            </TD>


                                            <TD class="tdbd_red_top1left1right2" width="80" height="25">
                                                비 고
                                            </TD>
                                        </TR>

                                        <TR>
                                            <TD class="tdbd_red_top1left2" align="middle" width="20"
                                                height="25">
                                                &#160;${ISSUE_DATE_MM}
                                            </TD>
                                            <TD class="tdbd_red_top1left1" align="middle" width="20"
                                                height="25">
                                                ${ISSUE_DATE_DD}
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="122" height="25">
                                             ${ITEM_NAME1}
                                            </TD>
                                            <TD class="tdbd_red_top1left1" width="70" height="25">
                                                &#160;
                                            </TD>
                                            <TD class="tdbd_red_top1left1" align="middle" width="30"
                                                height="25">
                                                &#160;
                                            </TD>
                                            <TD class="tdbd_red_top1left1" align="right" width="75" height="25">
                                                &#160;
                                            </TD>
                                            <TD class="tdbd_red_top1left1" align="right" width="100"
                                                height="25">
                                                <fmt:formatNumber value="${SUPPLY_PRICE}" type="number" groupingUsed="true"/>
                                                &#160;
                                            </TD>

                                            <TD class="tdbd_red_top1left1" align="right" width="95"
                                                height="25">
                                                <fmt:formatNumber value="${VAT_AMOUNT}" type="number" groupingUsed="true"/>
                                                &#160;
                                            </TD>

                                            <TD class="tdbd_red_top1left1right2" width="80" height="25">
                                                &#160;
                                            </TD>
                                        </TR>






                                        </TBODY>
                                    </TABLE>
                                    <TABLE cellSpacing="0" cellPadding="1" width="680" border="0">
                                        <TBODY>
                                        <TR align="middle">
                                            <TD class="tdbd_red_top1left2" vAlign="bottom" width="124" height="20">
                                                합 계 금 액
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" width="90" height="20">
                                                현 금
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" width="90" height="20">
                                                수 표
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" width="90" height="20">
                                                어 음
                                            </TD>
                                            <TD class="tdbd_red_top1left1" vAlign="bottom" width="90" height="20">
                                                외상미수금
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2bottom1" vAlign="center" width="110"
                                                rowSpan="2">
                                                위 금액을 <b>
                                                <FONT size="2">
                                                    영수

                                                </FONT>
                                            </b> 함.
                                            </TD>
                                        </TR>
                                        <TR>
                                            <TD class="tdbd_red_top1left2bottom1" align="right" width="124" height="30">
                                                &#160;<b>
                                                <FONT size="2" color="#000000">
                                                    <fmt:formatNumber value="${TOTAL_AMOUNT}" type="number" groupingUsed="true"/>
                                                </FONT>
                                            </b>
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" align="right" width="90" height="30">
                                                &#160;
                                                <FONT size="2" color="#000000">

                                                </FONT>
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" align="right" width="90" height="30">
                                                &#160;
                                                <FONT size="2" color="#000000">

                                                </FONT>
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" align="right" width="90" height="30">
                                                &#160;
                                                <FONT size="2" color="#000000">

                                                </FONT>
                                            </TD>
                                            <TD class="tdbd_red_top1left1bottom1" align="right" width="90" height="30">
                                                &#160;
                                                <FONT size="2" color="#000000">

                                                </FONT>
                                            </TD>
                                        </TR>
                                        </TBODY>
                                    </TABLE>
                                    <TABLE cellSpacing="0" cellPadding="1" width="680" border="0">
                                        <TBODY>
                                        <TR vAlign="middle" align="middle" height="40">
                                            <TD class="tdbd_red_top1left2bottom2" width="200">
                                                가 상 계 좌
                                            </TD>
                                            <TD class="tdbd_red_top1left1right2bottom2" colSpan="24" align="left">
                                                <DIV></DIV>
                                                <DIV></DIV>
                                                <DIV></DIV>
                                                <DIV></DIV>
                                                <DIV></DIV>
                                                <DIV class="bulkCd0085_textRedBold"/>
                                            </TD>
                                        </TR>
                                        </TBODY>
                                    </TABLE>
                                </TD>
                                <TD width="30" height="2">&#160;</TD>
                            </TR>
                            <TR>
                                <TD class="stylefont5" height="20">&#160;
                                </TD>
                                <TD class="stylefont5" align="right" height="20">&#160;
                                </TD>
                                <TD width="30" height="2">&#160;</TD>
                            </TR>
                            </TBODY>
                        </TABLE>
                        <TABLE cellSpacing="0" cellPadding="0" width="650" border="0">
                            <TBODY>
                            <TR>
                                <TD>주의: 본 세금계산서는 국세청고시 기준에 따라 발행된 전자세금계산서로 공인인증기관의 공인인증서를 사용하여
                                    <br/>전자서명되어 인감날인이 없어도 법적 효력을 갖습니다.
                                </TD>
                            </TR>
                            </TBODY>
                        </TABLE>
                    </TD>
                </TR>
                </TBODY>
            </TABLE>
        </TD>
    </TR>
    </TBODY>
</TABLE>
</body>
</html>
