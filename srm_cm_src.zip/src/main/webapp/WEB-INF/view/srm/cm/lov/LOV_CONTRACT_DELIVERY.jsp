<%@ taglib prefix="serarch" uri="http://www.matrix2b.com/jsp/tlds/search" %>
<%@ page contentType="text/html; charset=UTF-8"     pageEncoding="UTF-8"%>

<%@ include file="/WEB-INF/view/ca/common/tlds.jsp"%>


<view:view id="LOV_CONTRACT_DELIVERY" type="<%= ViewType.LOV %>"  session="<%=session%>" model="<%=request%>" >

    <view:title name="계약현황">
        <view:buttons>
            <view:button id="CLOSE"  label="닫기" />
        </view:buttons>
    </view:title>

    <view:view_so groupId="LOV_CONTRACT_DELIVERY">
        <search:so cols="2" rows="1"  fixedRows="0">

            <search:so_keyword     row="1" col="1"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="계약번호"   value="1" columnName="CT_NO" />
            </search:so_keyword>
            
            <search:so_keyword     row="1" col="1"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="계약명"   value="1" columnName="CT_NAME" />
            </search:so_keyword>
            
            <search:so_keyword     row="1" col="1"  selectedListItemId="1"  keyword="" >
                <search:so_keyword_item id="1" label="계약업체"   value="1" columnName="SUPPLIER_NAME" />
            </search:so_keyword>
            
            
            <search:so_paging rowsPerPage="500" />

        </search:so>
    </view:view_so>

    <view:view_toolbar groupId="LOV_CONTRACT_DELIVERY">
        <toolbar:toolbar  showTotal="true" showPaging="true" showReport="false" showGridSetting="false" showExcelDown="false" >
        </toolbar:toolbar>
        <button:buttons>
            <button:button id="SEARCH"  label="조 회"  href=""/>
        </button:buttons>
    </view:view_toolbar>

    <view:view_grid groupId="LOV_CONTRACT_DELIVERY">
        <grid:grid sortColumnId="CT_H_UID|CT_NO" sortDirection="ASC|ASC">
            <grid:column_txt id="COMPANY_NAME"          name="회사"                  width="100"  align="left"   />
            <grid:column_txt id="CT_NO"                 name="계약번호"              width="110"  align="center"  sortColumn="CT_NO" />
            <grid:column_txt id="CT_SEQ"                name="계약<br>차수"          width="050"  align="center" />
            <grid:column_txt id="CT_NAME"               name="계약명"                width="200"  align="left"   />
            <grid:column_txt id="CT_START_DATE"         name="계약일"              width="090"  align="center" />
            <grid:column_txt id="CT_END_DATE"           name="종료일"              width="090"  align="center" />
            <grid:column_num id="CT_AMOUNT"             name="계약금액"              width="110"  align="right"  formatter="<%=FMTType.AMT %>" currency="KRW" />
            
            <grid:hidden     id="SUPPLIER_CODE"      columnName="SUPPLIER_CODE"    />
            <grid:hidden     id="CT_H_UID"           columnName="CT_H_UID"        sortColumn="CT_H_UID" />
            <grid:hidden     id="PRICE_TYPE_CODE"    columnName="PRICE_TYPE_CODE"  />
            <grid:hidden     id="PRICE_TYPE_NAME"    columnName="PRICE_TYPE_NAME"  />
            <grid:hidden     id="STATUS"             columnName="STATUS"           />
            <grid:hidden     id="SUPPLIER_CODE"      columnName="SUPPLIER_CODE"    />
            <grid:hidden     id="SUPPLIER_NAME"      columnName="SUPPLIER_NAME"    />
            <grid:hidden     id="COMPANY_CODE"       columnName="COMPANY_CODE"     />
            
        </grid:grid>
    </view:view_grid>

</view:view>

<script>

function initPage(){
    InitRealGrids();
    resize();
    
  //grid header 높이 조절
    $.grid(0).header.height = 40;
    
    createHiddenParameter();
    $("input[name='KEYWORD_KEYWORD']").focus();
    doSearch();
}

</script>