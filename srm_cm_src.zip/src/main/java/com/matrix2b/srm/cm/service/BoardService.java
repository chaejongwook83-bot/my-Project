/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.service;

import com.matrix2b.mwf.exception.MwfAssert;
import com.matrix2b.mwf.exception.MwfRuntimeException;
import com.matrix2b.mwf.model.MwfMap;
import com.matrix2b.mwf.model.UserModelPart;
import com.matrix2b.mwf.mvc.MwfService;
import com.matrix2b.mwf.security.KeyEncryptor;
import com.matrix2b.mwf.util.CommonUtil;
import com.matrix2b.srm.cm.entity.MmBoardEntity;
import com.matrix2b.srm.cm.entity.MmBoardReEntity;
import com.matrix2b.srm.cm.mapper.BoardMapper;
import com.matrix2b.srm.cm.mapper.BoardReplyMapper;
import com.matrix2b.sys.attachment.service.CommonTransFileService;
import com.matrix2b.sys.inf.cm.InvokerService;
import com.matrix2b.sys.setup.service.TableHistoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 구매 소통게시판 Service
 * BoardService.java
 *
 * @author M2B
 * @version 1.0
 * @see <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2025-07-16      M2B      최초 생성
 * </pre>
 * @since 2025-07-16
 */
@Service
@RequiredArgsConstructor
public class BoardService extends MwfService {

    private final BoardMapper boardMapper;
    private final BoardReplyMapper boardReplyMapper;
    private final InvokerService invokerService;

    private final KeyEncryptor keyEncryptor;
    private final CommonTransFileService commonTransFileService;
    private final TableHistoryService tableHistoryService;

    /**
     * 구매 게시판 리스트 조회
     *
     * @param params
     * @return
     */
    public List<MwfMap<String, Object>> searchBoardList(MwfMap<String, Object> params) {
        return boardMapper.selectBoardList(params);
    }

    /**
     * (파트너사) 구매 게시판 리스트 조회
     *
     * @param params
     * @return
     */
    public List<MwfMap<String, Object>> searchBoardListForSuplier(MwfMap<String, Object> params) {

        return boardMapper.selectBoardListForSupplier(params);
    }

    /**
     * 문서기준 - 게시글 리스트 조회
     * (문서 상세화면 내 QnA게시판 조회)
     *
     * @param params
     * @return
     */
    public List<MwfMap<String, Object>> searchBoardListByDoc(MwfMap<String, Object> params) {
        String clientCode = params.getStringValue("CLIENT_CODE");
        String companyCode = params.getStringValue("COMPANY_CODE");
        String docUid = params.getStringValue("DOC_UID");
        String docType = params.getStringValue("DOC_TYPE_CODE");
        String regTypeCode = params.getStringValue("REG_TYPE_CODE");

        MwfAssert.notEmpty(clientCode, "clientCode is not null");
        MwfAssert.notEmpty(companyCode, "companyCode is not null");
        MwfAssert.notEmpty(docUid, "docUid is not null");
        MwfAssert.notEmpty(docType, "docType is not null");


        MwfMap<String, Object> paramMap = new MwfMap<>();
        paramMap.put("CLIENT_CODE", clientCode);
        paramMap.put("COMPANY_CODE", companyCode);
        paramMap.put("DOC_UID", docUid);
        paramMap.put("DOC_TYPE_CODE", docType);
        paramMap.put("REG_TYPE_CODE", regTypeCode);

        return boardMapper.selectBoardListByDoc(paramMap);
    }


    /**
     * (파트너사) 문서기준 - 협력사 게시글 리스트 조회
     * (문서 상세화면 내 협력사 QnA게시판 조회)
     *
     * @param params
     * @return
     */
    public List<MwfMap<String, Object>> searchBoardListByDocForSupplier(MwfMap<String, Object> params) {
        String clientCode = params.getStringValue("CLIENT_CODE");
        String companyCode = params.getStringValue("COMPANY_CODE");
        String docUid = params.getStringValue("DOC_UID");
        String docType = params.getStringValue("DOC_TYPE_CODE");

        MwfAssert.notEmpty(clientCode, "clientCode is not null");
        MwfAssert.notEmpty(companyCode, "companyCode is not null");
        MwfAssert.notEmpty(docUid, "docUid is not null");
        MwfAssert.notEmpty(docType, "docType is not null");


        MwfMap<String, Object> paramMap = new MwfMap<>();
        paramMap.put("CLIENT_CODE", clientCode);
        paramMap.put("COMPANY_CODE", companyCode);
        paramMap.put("DOC_UID", docUid);
        paramMap.put("DOC_TYPE_CODE", docType);
        paramMap.put("SUPPLIER_CODE", getUserModelPart().getCompanyCode());  // 파트너사 코드


        return boardMapper.selectBoardListByDocForSupplier(paramMap);
    }


    /**
     * 구매 게시글 상세조회
     *
     * @param uid
     * @return
     */
    public MwfMap<String, Object> getBoard(String uid) {
        return boardMapper.selectBoard(uid);
    }


    /**
     * 게시물 저장
     *
     * @param entryData
     * @return
     * @throws ParseException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public String saveBoard(MwfMap<String, Object> entryData) {

        String docTypeCode = entryData.getStringValue("DOC_TYPE_CODE");
        String ctHUids = entryData.getStringValue("CT_H_UIDS");
        String confirmOrgCode = entryData.getStringValue("CONFIRM_ORG_CODE");

        if (docTypeCode.startsWith("UCT") && !"".equals(ctHUids) && !"".equals(confirmOrgCode)) {

            return this.saveBoardUctAgree(entryData); // 도급 사전합의 다건 저장

        } else {

            //  entryData -> entity 변환
            MmBoardEntity entity = entryData.toBean(MmBoardEntity.class);

            // INSERT
            if (entity.getBoardUid() == null) {

                // 사전합의 중복저장 체크
                if (entity.getDocTypeCode().startsWith("UCT")) {
                    MmBoardEntity checkEntity = new MmBoardEntity();
                    checkEntity.setActvFlag("Y");
                    checkEntity.setDocTypeCode(entity.getDocTypeCode());
                    checkEntity.setDocUid(entity.getDocUid());

                    if (boardMapper.selectCountByCriteria(checkEntity) > 0) {
                        throw new MwfRuntimeException(getMessage("E-CT-052")); // 이미 사전합의 처리된 건이 존재합니다.
                    }
                }

                entity.setBoardUid(boardMapper.selectKey(entity));

                // 신규저장 시점 작성자 구분 ( H:회사 (내부담당자), V:벤더 (파트너사) )
                entity.setRegTypeCode("H"); // 내부담당자
                if ("Y".equals(entryData.getStringValue("SUPPLIER_FLAG"))) {
                    entity.setRegTypeCode("V"); // 파트너사
                    entity.setSupplierCode(getUserModelPart().getCompanyCode());  // 협력사코드
                }

                entity.validate();
                boardMapper.insert(entity);

                MwfMap<String, Object> addParams = new MwfMap<>();

                String messageCode = "";

                // 최초 저장 시 메일발송
                if ("H".equals(entity.getRegTypeCode())) {
                    // 도급입찰 RFP검토게시판 메일발송
                    // - MM-URX-017 - 구매팀에서 RFP검토 작성 시, 운영부서 담당자에게 - [도급] 입찰서류 검토의견 회신
                    // - MM-URX-018 - 운영부서에서 RFP검토 작성 시, 도급구매 권한자 모두에게 - [도급] 입찰서류 재수정 회신
                    if ("UBD_RFP".equals(entity.getDocTypeCode())) {
                        messageCode = ("OA".equals(CommonUtil.getUserModelPart().getGrantGroupCode())) ? "MM-URX-017" : "MM-URX-018";
                    }
                    // 도급입찰 소통게시판 메일발송
                    // - MM-URX-023 - 구매팀에서 소통게시판 작성 시, 운영부서 담당자에게 - [도급] 질의 회신 등록 안내
                    else if ("UBD_COMMU".equals(entity.getDocTypeCode())) {
                        messageCode = "MM-URX-023";
                    }
                    // 도급입찰 QnA게시판 메일발송
                    // - MM-URX-025 - 구매팀에서, QnA 작성 시, 협력사에 - [도급] 입찰 질의사항 회신안내
                    else if ("UBD".equals(entity.getDocTypeCode())) {
                        messageCode = "MM-URX-025";
                    }
                    //[일반구매] 견적/입찰 질의사항 회신
                    else if ("RQ".equals(entity.getDocTypeCode()) || "BD".equals(entity.getDocTypeCode())) {
                        messageCode = "MM-RX-024";
                    }

                } else {
                    // 도급입찰 QnA게시판 메일발송
                    // - MM-URX-022 - 협력사에서 QnA 작성 시, 도급구매 담당자에게 - [도급] 질의사항 접수
                    if ("UBD".equals(entity.getDocTypeCode())) {
                        messageCode = "MM-URX-022";
                    }
                    // [일반구매] 파트너사 질의사항 등록 시 검토/구매 부서 담당자에게 알림메세지 전송
                    else if ("RQ".equals(entity.getDocTypeCode()) || "BD".equals(entity.getDocTypeCode())) {
                        messageCode = "MM-RX-029";
                        addParams.put("SUPPLIER_CODE", entity.getSupplierCode());
                    }
                }

                if (!"".equals(messageCode)) {
                    if (entity.getDocTypeCode().startsWith("UBD")) {
                        //urfxService.requestQuotationSendMessage(entity.getDocUid().toString(), messageCode, null, new String[] {"DOC_TITLE"}, new String[] {entity.getTitle()});
                        Class<?>[] paramTypes = {String.class, String.class, String.class, String[].class, String[].class};
                        Object[] args = {entity.getDocUid().toString(), messageCode, null, new String[]{"DOC_TITLE"}, new String[]{entity.getTitle()}};
                        invokerService.callMulti("com.matrix2b.srm.mm.rx.service.URfxService", "requestQuotationSendMessage", Void.class, paramTypes, args);
                    } else {
                        // 일반구매(견적/입찰) 알림메세지 전송
                        Class<?>[] paramTypes = {String.class, String.class, MwfMap.class};
                        Object[] args = {entity.getDocUid().toString(), messageCode, addParams};
                        invokerService.callMulti("com.matrix2b.srm.mm.rx.service.RfxSendMessageService", "sendMessage", Integer.class, paramTypes, args);
                    }
                }

            }
            // UPDATE
            else {
                this.updateValidation("SAVE", entity.getBoardUid());
                boardMapper.updateByPrimaryKey(entity);
            }

            //히스토리 저장
            tableHistoryService.saveTargetTableHistory("MM_BOARD", entity.getBoardUid().toString(), "ENT", "[SAVE]저장");

            return entity.getBoardUid().toString();
        }

    }


    /**
     * 게시글 리스트 삭제
     *
     * @param gridData
     * @return
     */
    public int deleteBoardList(MwfMap<String, Object> gridData, String gridId) {
        List<MwfMap<String, Object>> data = (ArrayList<MwfMap<String, Object>>) gridData.get(gridId);
        int rowDataCnt;
        List<BigInteger> arrUid = data.stream()
                .map(item -> item.getBigIntegerValue("BOARD_UID"))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        List<MmBoardEntity> boardList = boardMapper.selectEntityListByPrimaryKeyIn(arrUid);
        rowDataCnt = boardList.size();
        for (int idx = 0; idx < rowDataCnt; idx++) {
            // Board Entity
            MmBoardEntity boardEntity = boardList.get(idx);
            BigInteger boardUid = boardEntity.getBoardUid();

            // 단건 삭제 호출
            this.deleteBoard(boardUid);
        }

        return rowDataCnt;

    }

    /**
     * 게시글 삭제
     *
     * @param entryData
     * @return
     */
    public void deleteBoard(MwfMap<String, Object> entryData) {
        String uid = entryData.getStringValue("BOARD_UID");
        MwfAssert.notBlank(uid, "Uid must not be null.");

        ArrayList<MwfMap<String, Object>> targetCt = (ArrayList<MwfMap<String, Object>>) entryData.get("GRID_TARGET_CT");

        if (targetCt == null || targetCt.size() == 0) {
            this.deleteBoard(new BigInteger(uid));
        } else {
            for (MwfMap<String, Object> boardCtAgreeMap : targetCt) {
                uid = boardCtAgreeMap.getStringValue("BOARD_UID");
                if (uid != null && !"".equals(uid)) {
                    this.deleteBoard(new BigInteger(uid));
                }
            }
        }
    }

    public void deleteBoard(BigInteger boardUid) {

        // validation 체크
        this.updateValidation("DELETE", boardUid);

        // 답글 체크
        MmBoardReEntity boardReEntity = new MmBoardReEntity();
        boardReEntity.setBoardUid(boardUid);
        boardReEntity.setActvFlag("Y");
        long replyCnt = boardReplyMapper.selectCountByCriteria(boardReEntity);
        if (replyCnt > 0) {
            throw new MwfRuntimeException("답글이 존재하여 삭제할 수 없습니다.");
        }

        // 게시글 삭제
        boardMapper.deleteFakeByPrimaryKey(boardUid);

        //게시글-답글 삭제
        boardReplyMapper.deleteFakeByCriteria(boardReEntity);

        //히스토리 저장
        tableHistoryService.saveTargetTableHistory("MM_BOARD", boardUid.toString(), "DEL", "[DELETE]삭제");
    }


    /**
     * update로직 validation
     * 자신의 글 만 수정가능하게함. 시스템관리자는 다 가능
     *
     * @param actionId
     * @param uid      (BOA
     */
    private void updateValidation(String actionId, BigInteger uid) {
        UserModelPart ump = getUserModelPart();
        MwfMap<String, Object> checkMap = new MwfMap<>();

        if (actionId.indexOf("_REPLY") > -1) {
            // 답글 check
            checkMap = boardReplyMapper.selectByPrimaryKey(uid);
        } else {
            // 게시글 check
            checkMap = boardMapper.selectByPrimaryKey(uid);
        }

        // 1. Login UserId != 최초등록자 ID (REG_ID)
        if (!ump.getUserId().equals(checkMap.getStringValue("REG_ID"))
            // && !ump.getGrantGroupCode().equals("SA")   // 관리자 - 임시 제외 주석처리
        ) {

            throw new MwfRuntimeException(getMessage("E-CT-047")); // 등록자와 같지 않은 사용자입니다.
        }


    }


    /**
     * 게시글 -답글 조회
     *
     * @param uid
     * @return
     */
    public List<MwfMap<String, Object>> selectBoardReplyList(String uid) {
        MwfMap<String, Object> param = new MwfMap<>();
        param.put("BOARD_UID", uid);

        List<MwfMap<String, Object>> result = boardReplyMapper.selectBoardReplyList(param);

        return result;
    }

    /**
     * 게시글 -답글 저장
     *
     * @param entryData
     * @return
     * @throws ParseException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public String saveBoardReply(MwfMap<String, Object> entryData) {

        MwfMap<String, Object> replyMap = new MwfMap<>();

        String reIdx = entryData.getStringValue("REPLY_INDEX");
        replyMap.put("BOARD_UID", entryData.getStringValue("BOARD_UID"));
        replyMap.put("BOARD_RE_UID", entryData.getStringValue("BOARD_RE" + reIdx + "_UID"));
        replyMap.put("REPLY_CONTENT", entryData.getStringValue("REPLY_CONTENT" + reIdx));

        // 답글 entity
        MmBoardReEntity entity = replyMap.toBean(MmBoardReEntity.class);

        // INSERT
        if (entity.getBoardReUid() == null) {
            entity.setBoardReUid(boardReplyMapper.selectKey(entity));
            entity.setStatus("ENT");

            // 신규저장 시점 작성자 구분 ( H:회사 (내부담당자), V:벤더 (파트너사) )
            entity.setRegTypeCode("H"); // 내부담당자
            if ("Y".equals(entryData.getStringValue("SUPPLIER_FLAG"))) {
                entity.setRegTypeCode("V"); // 파트너사
                entity.setSupplierCode(getUserModelPart().getCompanyCode());
            }

            entity.validate();
            boardReplyMapper.insert(entity);

            if(entryData.getStringValue("DOC_TYPE_CODE").startsWith("UCT")){
                entryData.put("CT_H_UID",entryData.getStringValue("DOC_UID"));
                invokerService.call("com.matrix2b.srm.mm.ct.service.SubContractService", "notifyRequestPreAgreementOpinion",  MwfMap.class, Void.class, entryData);
            }
            // UPDATE
        } else {
            // 유효성 체크
            this.updateValidation("SAVE_REPLY", entity.getBoardReUid());

            boardReplyMapper.updateByPrimaryKey(entity);
        }

        return entity.getBoardUid().toString();

    }

    /**
     * 게시글 -답글 삭제
     *
     * @param entryData
     * @return
     */
    public String deleteReply(MwfMap<String, Object> entryData) {

        // 삭제 target 답글 index
        String reIdx = entryData.getStringValue("REPLY_INDEX");
        // 해당 index의 답글 UID 가져오기
        String replyUid = entryData.getStringValue("BOARD_RE" + reIdx + "_UID");

        MwfAssert.notBlank(replyUid, "uid must not be null.");

        // 유효성 체크
        this.updateValidation("DELETE_REPLY", new BigInteger(replyUid));

        // 답글 삭제 처리
        boardReplyMapper.deleteFakeByPrimaryKey(new BigInteger(replyUid));

        return entryData.getStringValue("BOARD_UID");
    }

    /**
     * 게시판 - 검토완료 처리
     *
     * @param entryData
     * @return int
     */
    public int updateBoardConfirm(MwfMap<String, Object> entryData) {
        int result = 0;

        UserModelPart ump = getUserModelPart();
        String[] uids = entryData.getStringValue("BOARD_UIDS").split(",");

        String boardUid = "";
        for (int i = 0; i < uids.length; i++) {
            boardUid = keyEncryptor.decrypt(uids[i]);

            MmBoardEntity boardEntity = new MmBoardEntity();
            boardEntity.setBoardUid(new BigInteger(boardUid));
            boardEntity.setConfirmFlag("Y"); // 검토완료 처리
            boardEntity.setConfirmUserId(ump.getUserId()); // 합의자
            boardMapper.updateByPrimaryKey(boardEntity);

            result++;
        }

        return result;
    }

    public MwfMap<String, Object> checkPossibleQnaDate(String rxHUid) {
        MwfMap<String, Object> params = new MwfMap<>();
        params.put("RX_H_UID", rxHUid);

        return boardMapper.checkPossibleQnaDate(params);

    }

    /**
     * 도급 사전합의 처리할 도급 계약정보 조회
     * 
     * @param uids
     * @return
     */
    public List<MwfMap<String, Object>> searchSubContractAgreeTargetList(String uids, String confirmOrgCode) {
        MwfMap<String, Object> params = new MwfMap<>();
        params.put("UIDS", Arrays.stream(uids.split(",")).map(keyEncryptor::decrypt).distinct().toArray(String[]::new));
        params.put("CONFIRM_ORG_CODE", confirmOrgCode);
        params.put("USER_LANGUAGE", getUserModelPart().getLanguage());
        return boardMapper.searchSubContractAgreeTargetList(params);
    }

    /**
     * 도급 사전합의 다건 저장
     *
     * @param entryData
     * @return
     */
    public String saveBoardUctAgree(MwfMap<String, Object> entryData) {

        int saveCnt = 0;
        String uid = "", title = "", content = "";

        ArrayList<MwfMap<String, Object>> targetCt = (ArrayList<MwfMap<String, Object>>) entryData.get("GRID_TARGET_CT");

        if (targetCt == null || targetCt.size() == 0) {
            throw new MwfRuntimeException("사전합의 계약정보가 없습니다.");

        } else {
            MmBoardEntity entity = entryData.toBean(MmBoardEntity.class);

            for (MwfMap<String, Object> boardCtAgreeMap : targetCt) {
                //entity = boardCtAgreeMap.toBean(MmBoardEntity.class);

                entity.setBoardUid(boardCtAgreeMap.getBigIntegerValue("BOARD_UID"));
                entity.setDocUid(boardCtAgreeMap.getBigIntegerValue("DOC_UID"));
                entity.validate();

                if (saveCnt > 1) {
                    entity.setTitle(title);
                    entity.setContent(content);
                }

                // INSERT
                if (entity.getBoardUid() == null) {

                    // 사전합의 중복저장 체크
                    if (entity.getDocTypeCode().startsWith("UCT")) {
                        MmBoardEntity checkEntity = new MmBoardEntity();
                        checkEntity.setActvFlag("Y");
                        checkEntity.setDocTypeCode(entity.getDocTypeCode());
                        checkEntity.setDocUid(entity.getDocUid());

                        if (boardMapper.selectCountByCriteria(checkEntity) > 0) {
                            throw new MwfRuntimeException(getMessage("E-CT-052")); // 이미 사전합의 처리된 건이 존재합니다.
                        }
                    }

                    entity.setBoardUid(boardMapper.selectKey(entity));
                    entity.setRegTypeCode("H"); // 내부담당자
                    entity.validate();
                    boardMapper.insert(entity);
                }
                // UPDATE
                else {
                    this.updateValidation("SAVE", entity.getBoardUid());
                    boardMapper.updateByPrimaryKey(entity);
                }
                saveCnt++;

                if (saveCnt == 1) {
                    uid = entity.getBoardUid().toString();
                    title = entity.getTitle();
                    content = entity.getContent();
                }

                //히스토리 저장
                tableHistoryService.saveTargetTableHistory("MM_BOARD", entity.getBoardUid().toString(), "ENT", "[SAVE]저장");
            }
        }

        return uid;
    }

    /**
     * 도급 사전합의 다건 상태값 갱신
     *
     * @param entryData
     * @return
     */
    public String updateBoardAgree(MwfMap<String, Object> entryData) {

        String changeStatus = entryData.getStringValue("CHANGE_STATUS");
        String actionName = "";
        ArrayList<MwfMap<String, Object>> targetCt = (ArrayList<MwfMap<String, Object>>) entryData.get("GRID_TARGET_CT");

        if (targetCt == null || targetCt.size() == 0) {

            MmBoardEntity boardEntity = new MmBoardEntity();
            boardEntity.setBoardUid(entryData.getBigIntegerValue("BOARD_UID"));
            boardEntity.setStatus(changeStatus);
            boardEntity.setConfirmUserId(getUserModelPart().getUserId()); // 합의자
            if (Arrays.asList("AGR").contains(changeStatus)) {
                boardEntity.setConfirmFlag("Y"); // 검토완료 처리
                actionName = "[" + changeStatus + "]" + "합의";
            } else if ("DIS".equals(changeStatus)) {
                actionName = "[" + changeStatus + "]" + "불합의";
            } else if ("CAG".equals(changeStatus)) {
                actionName = "[" + changeStatus + "]" + "조건부합의";
            }
            boardMapper.updateByPrimaryKey(boardEntity);
            //사전합의 후 계약 보고 진행 요청 알림 호출
            entryData.put("CT_H_UID", entryData.getBigIntegerValue("DOC_UID"));
            invokerService.call("com.matrix2b.srm.mm.ct.service.SubContractService", "notifyPreAgreementCompleted",  MwfMap.class, Void.class, entryData);

            //히스토리 저장
            tableHistoryService.saveTargetTableHistory("MM_BOARD", boardEntity.getBoardUid().toString(), changeStatus, actionName);

        } else {

            int saveCnt = 0;
            String title = "", content = "";

            MmBoardEntity boardEntity = entryData.toBean(MmBoardEntity.class);

            for (MwfMap<String, Object> boardCtAgreeMap : targetCt) {
                boardEntity.setBoardUid(boardCtAgreeMap.getBigIntegerValue("BOARD_UID"));
                boardEntity.setDocUid(boardCtAgreeMap.getBigIntegerValue("DOC_UID"));
                boardEntity.setStatus(changeStatus);
                boardEntity.setConfirmUserId(getUserModelPart().getUserId()); // 합의자
                if (Arrays.asList("AGR").contains(changeStatus)) {
                    boardEntity.setConfirmFlag("Y"); // 검토완료 처리
                    actionName = "[" + changeStatus + "]" + "합의";
                } else if ("DIS".equals(changeStatus)) {
                    actionName = "[" + changeStatus + "]" + "불합의";
                } else if ("CAG".equals(changeStatus)) {
                    actionName = "[" + changeStatus + "]" + "조건부합의";
                }

                if (saveCnt > 1) {
                    boardEntity.setTitle(title);
                    boardEntity.setContent(content);
                }

                // INSERT
                if (boardEntity.getBoardUid() == null) {
                    boardEntity.setBoardUid(boardMapper.selectKey(boardEntity));
                    boardEntity.setRegTypeCode("H"); // 내부담당자
                    boardEntity.validate();
                    boardMapper.insert(boardEntity);

                    //히스토리 저장
                    tableHistoryService.saveTargetTableHistory("MM_BOARD", boardEntity.getBoardUid().toString(), "ENT", "[SAVE]저장");
                }
                // UPDATE
                else {
                    boardMapper.updateByPrimaryKey(boardEntity);
                }
                saveCnt++;

                if (saveCnt == 1) {
                    title = boardEntity.getTitle();
                    content = boardEntity.getContent();
                }

                //사전합의 후 계약 보고 진행 요청 알림 호출
                boardCtAgreeMap.put("CT_H_UID", boardCtAgreeMap.getBigIntegerValue("DOC_UID"));
                invokerService.call("com.matrix2b.srm.mm.ct.service.SubContractService", "notifyPreAgreementCompleted",  MwfMap.class, Void.class, boardCtAgreeMap);

                //히스토리 저장
                tableHistoryService.saveTargetTableHistory("MM_BOARD", boardEntity.getBoardUid().toString(), changeStatus, actionName);
            }

        }

        return entryData.getStringValue("BOARD_UID");
    }

}
