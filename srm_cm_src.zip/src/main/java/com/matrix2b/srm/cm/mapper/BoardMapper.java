/*
 * Copyrightⓒ 2020. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.mapper;

import com.matrix2b.mwf.model.MwfMap;
import com.matrix2b.mwf.mybatis.BaseMapper;
import com.matrix2b.srm.cm.entity.MmBoardEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

/**
 * 게시판 Mapper
 *
 * @author  M2B
 * @version 1.0
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일         수정자                수정내용
 *  ==========    ==========    ============================
 *  2025-07-17       M2B        최초 생성
 * </pre>
 *
 */
@Mapper
@Repository
public interface BoardMapper extends BaseMapper<BigInteger, MmBoardEntity> {

    /**
     * 구매게시판 리스트 조회
     * @param params
     * @return
     */
    List<MwfMap<String, Object>> selectBoardList(MwfMap<String, Object> params);

    /**
     * 문서기준 - 구매게시판 리스트 조회
     * @param params
     * @return
     */
    List<MwfMap<String, Object>> selectBoardListByDoc(MwfMap<String, Object> params);


    /**
     * (파트너사) 구매게시판 리스트 조회
     * @param params
     * @return
     */
    List<MwfMap<String, Object>> selectBoardListForSupplier(MwfMap<String, Object> params);

    /**
     * (파트너사) 문서기준 - 구매게시판 리스트 조회
     * @param params
     * @return
     */
    List<MwfMap<String, Object>> selectBoardListByDocForSupplier(MwfMap<String, Object> params);


    /**
     * 구매게시판 상세조회
     * @param uid
     * @return
     */
    MwfMap<String, Object> selectBoard(String uid);

    /**
     * 일반구매 견적/입찰 질의가능시간 체크
     * @param params
     * @return
     */
    public MwfMap<String, Object> checkPossibleQnaDate(MwfMap<String, Object> params);


    /**
     * 사전합의 처리할 도급 계약정보 조회
     * @param params
     * @return
     */
    public List<MwfMap<String, Object>> searchSubContractAgreeTargetList(MwfMap<String, Object> params);


}
