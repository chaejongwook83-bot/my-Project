/*
 * Copyrightⓒ (주)매트릭스투비. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of www.matrix2b.com.,LTD.
 */
package com.matrix2b.srm.cm.sign.vo;

import com.matrix2b.mwf.model.MwfMap;

import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 *  계약서 검증 
 * </pre>
 * @date    2018. 7. 30. 오전 9:03:19
 * @author  M1Y0184
 * @version 1.0
 */
 /* -----------------------------------------------------------------------
 *  변경일             작성자             변경내용
 *  ----------- ------------------- ---------------------------------------
 *  2019. 6. 13.    PYB         최초 작성
 *  ----------------------------------------------------------------------
 */
public class VerifyManager {
    
    //계약서 검증목록
    ArrayList<VerifyVO> verifys;
            
    //계약서 첨부 목록
    List<MwfMap<String, Object>> attachFiles;
    
    //계약문서번호
    String docName;

    String contractName;
    
    //차수번호
    String seq;

    //계약서 상태
    String docStatus;

    public VerifyManager() {
        this.verifys = new ArrayList<VerifyVO>();
    }

    public ArrayList<VerifyVO> getVerifys() {
        return verifys;
    }

    public void setVerifys(ArrayList<VerifyVO> verifys) {
        this.verifys = verifys;
    }

    public List<MwfMap<String, Object>> getAttachFiles() {
        return attachFiles;
    }

    public void setAttachFiles(List<MwfMap<String, Object>> attachFiles) {
        this.attachFiles = attachFiles;
    } 
            
    public void addVerify(VerifyVO verify){
        this.verifys.add(verify);
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }


    public String getContractName() {
        return contractName;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    public String getDocStatus() {
        return docStatus;
    }

    public void setDocStatus(String docStatus) {
        this.docStatus = docStatus;
    }

}
