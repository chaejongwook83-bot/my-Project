/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.sign;

import com.matrix2b.srm.cm.sign.vo.SignContract;
import com.matrix2b.srm.cm.sign.vo.SignInfo;

/**
 * @author  jyp
 * @since   2021-06-24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-06-24      jyp        최초 생성
 * </pre>
 *
 */
public interface SignKit {
	/**
     * SignInfo 서명
     * @param signInfo
     */
    public void envelopd(SignInfo signInfo) throws Exception;
    
    /**
     * 데이터 서명
     * @param data
     * @return 서명데이터
     */
    public SignContract sign(String data, String orgData) throws Exception;
}
