/*
 * Copyrightⓒ 2020. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.lov.controller;

import com.matrix2b.ca.common.CommonService;
import com.matrix2b.mwf.model.MwfMap;
import com.matrix2b.mwf.ui.annotation.MwfAnnotation;
import com.matrix2b.mwf.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;

/**
 *  LOV 공통 컨트롤러 Class
 *
 * @author  PYB
 * @version 1.0
 * @since   2021-01-27
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일         수정자                수정내용
 *  ==========    ==========    ============================
 *  2021-01-27       PYB        최초 생성
 * </pre>
 *
 */
@Controller
@RequestMapping(value="/srm/cm/lov/{VIEW_ID}",method = RequestMethod.POST)
public class LovSrmController {

    @Autowired
    private CommonService commonService;

    /**
     * LOV 페이지로 이동한다.
     * @param map
     * @param viewId
     * @return ModelAndView
     */
    @RequestMapping(value="/FORWARD",method = RequestMethod.POST)
    public ModelAndView doForward(MwfMap<String, Object> map,  @PathVariable("VIEW_ID") String  viewId) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("/srm/cm/lov/" + viewId);
        mv.addAllObjects(map);
        return mv;
    }

    /**
     * Lov조회
     * @param params  파라미터맵핑객체
     * @param viewId  화면ID
     * @return
     */
    @RequestMapping(value="/SEARCH",method = RequestMethod.POST)
    @ResponseBody
    @MwfAnnotation
    public List<Map<String, Object>> search(MwfMap<String, Object> params, @PathVariable("VIEW_ID") String  viewId) {
        String mapperNS = "com.matrix2b.srm.cm.lov.mapper" + "." + viewId;
        String actionId = "SEARCH";
        CommonUtil.updateLovCompanyParam(params);
        return commonService.searchCommonLovList(mapperNS, actionId, params);
    }
}