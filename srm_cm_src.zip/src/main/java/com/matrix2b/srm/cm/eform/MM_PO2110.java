/*
 * Copyrightⓒ 2024. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.eform;

import com.matrix2b.mwf.exception.MwfRuntimeException;
import com.matrix2b.mwf.util.DateUtil;
import com.matrix2b.srm.cm.eform.vo.SignType;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;


/**
 * 충전지시 및 기록서
 * @author  PYB
 * @since   2024-07-16
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2024-07-16      PYB          최초 생성
 * </pre>
 *
 */
public class MM_PO2110 extends DeliveryCertificateDocument {


    public MM_PO2110(HashMap<String, String> signerInfo, HashMap<String, String> signInfo, String fileInfo) {
        super(signerInfo, signInfo, fileInfo);
    }

    @Override
    public void submit() {
        write("SUBMIT");
    }

    @Override
    public void approve() {
        write("APPROVE");
    }

    @Override
    public void receipt() {
        write("RECEIPT");
    }

    @Override
    public void receiptCancel() {
        write("RECEIPT_CANCEL");
    }

    private void write(String signType){
        String pdfFilePath  = this.fileInfo;
        int pageNumber      = 0;

        String date = DateUtil.getNowDate("yyyy.MM.dd");

        try {
            // 기존 PDF 문서 로드
            PDDocument document = PDDocument.load(new File(pdfFilePath));

            // 이미지 삽입할 페이지 선택
            PDPage page = document.getPage(pageNumber);

            PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true);

            // 이미지 객체 생성
            if("SUBMIT".equals(signType)){

                PDImageXObject confirm = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.CONFIRM.val())), document);
                PDImageXObject write   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.WRITE.val())), document);

                contentStream.drawImage(confirm, 535, 280, 25,25);
                contentStream.drawImage(confirm, 535, 580, 25,25);

                //작성자
                contentStream.drawImage(write, 120, 45, 80,20);

                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(130, 27, 60, 12);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(135, 29);
                contentStream.showText(date);
                contentStream.endText();

            }else if("RECEIPT".equals(signType)){

                PDImageXObject receipt   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.RECEIPT.val())), document);

                //검토
                contentStream.drawImage(receipt, 300, 45, 80,20);

                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(310, 27, 60, 12);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(315, 29);
                contentStream.showText(date);
                contentStream.endText();

            }else if("RECEIPT_CANCEL".equals(signType)){

                contentStream.setNonStrokingColor(255, 255, 255);

                contentStream.addRect(300, 45, 80,20);
                contentStream.fill();

                contentStream.addRect(310, 27, 60, 12);
                contentStream.fill();

            }else if("APPROVE".equals(signType)){

                PDImageXObject approve   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.APPROVE.val())), document);

                //승인
                contentStream.drawImage(approve, 480, 45, 80,20);

                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(490, 27, 60, 12);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(495, 29);
                contentStream.showText(date);
                contentStream.endText();

            }

            contentStream.close();

            document.save(pdfFilePath);
            document.close();


        } catch (IOException e) {
            throw new MwfRuntimeException("서명시 오류가 발생하였습니다.");
        }
    }

}