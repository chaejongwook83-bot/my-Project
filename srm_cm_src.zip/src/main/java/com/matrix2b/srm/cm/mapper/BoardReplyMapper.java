/*
 * Copyrightⓒ 2020. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.mapper;

import com.matrix2b.mwf.model.MwfMap;
import com.matrix2b.mwf.mybatis.BaseMapper;
import com.matrix2b.srm.cm.entity.MmBoardReEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

/**
 * 게시판-답글 Mapper
 *
 * @author  M2B
 * @version 1.0
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일         수정자                수정내용
 *  ==========    ==========    ============================
 *  2025-07-17       M2B        최초 생성
 * </pre>
 *
 */
@Mapper
@Repository
public interface BoardReplyMapper extends BaseMapper<BigInteger, MmBoardReEntity> {

    /**
     * 게시글 답글 리스트 조회
     * @param param
     * @return
     */
    List<MwfMap<String, Object>> selectBoardReplyList(MwfMap param);

}
