/*
 * Copyrightⓒ 2024. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.eform;

import java.util.HashMap;

/**
 * 생산서류 관리 클래스
 * @author  PYB
 * @since   2024-07-16
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2024-07-16      PYB          최초 생성
 * </pre>
 *
 */
public abstract class DeliveryCertificateDocument {

    protected HashMap<String, String> signerInfo;
    protected HashMap<String, String> signInfo;
    protected String                 fileInfo;

    public DeliveryCertificateDocument(HashMap<String, String> signerInfo, HashMap<String, String> signInfo, String fileInfo) {
        this.signerInfo = signerInfo;
        this.signInfo   = signInfo;
        this.fileInfo   = fileInfo;
    }

    public abstract void submit();
    public abstract void receipt();
    public abstract void receiptCancel();
    public abstract void approve();
}