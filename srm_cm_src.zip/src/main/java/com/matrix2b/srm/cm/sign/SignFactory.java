/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.sign;

import com.matrix2b.mwf.exception.MwfRuntimeException;

/**
 * 서명 툴킷 Factory
 * @author  jyp
 * @since   2021-06-24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-06-24      jyp        최초 생성
 * </pre>
 *
 */
public class SignFactory {

	private SignFactory() {
		throw new UnsupportedOperationException("Utility class cannot be instantiated");
	}

	public static SignKit getSignKit(String kitType , String companyCode) {
	        
	        SignKit signer = null;
	        
	        if(kitType.equalsIgnoreCase("TRADESIGN")){
	            signer = new TradeSign(companyCode);
	        }
	        
	        if(signer == null) {
	            throw new MwfRuntimeException("Not Supported Sign Kit Exception.");
	        }
	        return signer;
	        
	    }
	
}
