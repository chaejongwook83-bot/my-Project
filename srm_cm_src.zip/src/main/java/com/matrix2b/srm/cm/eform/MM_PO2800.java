/*
 * Copyrightⓒ 2024. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.eform;

import com.matrix2b.mwf.exception.MwfRuntimeException;
import com.matrix2b.mwf.util.DateUtil;
import com.matrix2b.srm.cm.eform.vo.SignType;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;


/**
 * 충포장지시 및 기록서
 * @author  PYB
 * @since   2024-07-16
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2024-07-16      PYB          최초 생성
 * </pre>
 *
 */
public class MM_PO2800 extends DeliveryCertificateDocument {


    public MM_PO2800(HashMap<String, String> signerInfo, HashMap<String, String> signInfo, String fileInfo) {
        super(signerInfo, signInfo, fileInfo);
    }

    @Override
    public void submit() {
        write("SUBMIT");
    }

    @Override
    public void approve() {}

    @Override
    public void receipt() {}

    @Override
    public void receiptCancel() {}


    private void write(String signType){
        String pdfFilePath  = this.fileInfo;
        int pageNumber      = 0;

        String date = DateUtil.getNowDate("yyyy.MM.dd");

        try {
            // 기존 PDF 문서 로드
            PDDocument document = PDDocument.load(new File(pdfFilePath));

            // 이미지 삽입할 페이지 선택
            PDPage page = document.getPage(pageNumber);

            PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true);

            // 이미지 객체 생성
            if("SUBMIT".equals(signType)){

                PDImageXObject examin   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.EXAMIN.val())), document);
                PDImageXObject confirm  = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.CONFIRM.val())), document);

                // 검사자
                contentStream.drawImage(examin, 335, 740, 70,15);

                // 확인자
                contentStream.drawImage(confirm, 512, 687, 55,15);

            }else if("RECEIPT".equals(signType)){
            }else if("APPROVE".equals(signType)){}

            contentStream.close();

            document.save(pdfFilePath);
            document.close();


        } catch (IOException e) {
            throw new MwfRuntimeException("서명시 오류가 발생하였습니다.");
        }
    }

}