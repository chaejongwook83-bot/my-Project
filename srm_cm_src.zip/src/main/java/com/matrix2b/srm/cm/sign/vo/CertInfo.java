/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.sign.vo;

import lombok.Data;

/**
 * @author  jyp
 * @since   2021-06-24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-06-24      jyp        최초 생성
 * </pre>
 *
 */
@Data
public class CertInfo {
	
	private String authorityInfoAddress;    
    private String authorityKeyID;
    private String basicConstraint;
    private String cert;
    private String certPath;
    private String certPolicy;
    private String crlDP;
    private String extKeyUsage;
    private String issuerDN;
    private String keyUsage;
    private String kmCert;
    private String serialNumberDec;
    private String serialNumberHex;
    private String signature;
    private String signatureAlgorithm;
    private String storageType;        
    private String subjectAltName;
    private String subjectDN;
    private String subjectKeyID;
    private String subjectPublicKey;
    private String subjectPublicKeyAlgorithm;
    private String valid;
    private String validFrom;
    private String validTo;
    private String version;
	
}
