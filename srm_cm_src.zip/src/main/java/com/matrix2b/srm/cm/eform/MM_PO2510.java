/*
 * Copyrightⓒ 2024. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.eform;

import com.matrix2b.mwf.exception.MwfRuntimeException;
import com.matrix2b.mwf.util.DateUtil;
import com.matrix2b.srm.cm.eform.vo.SignType;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;


/**
 * 충포장 공정검사 기록서
 * @author  PYB
 * @since   2024-07-16
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2024-07-16      PYB          최초 생성
 * </pre>
 *
 */
public class MM_PO2510 extends DeliveryCertificateDocument {


    public MM_PO2510(HashMap<String, String> signerInfo, HashMap<String, String> signInfo, String fileInfo) {
        super(signerInfo, signInfo, fileInfo);
    }

    @Override
    public void submit() {
        write("SUBMIT");
    }

    @Override
    public void approve() {
        write("APPROVE");
    }

    @Override
    public void receipt() {
        write("RECEIPT");
    }

    @Override
    public void receiptCancel() {
        write("RECEIPT_CANCEL");
    }


    private void write(String signType){
        String pdfFilePath  = this.fileInfo;
        int pageNumber      = 0;

        String date = DateUtil.getNowDate("yyyy.MM.dd");

        try {
            // 기존 PDF 문서 로드
            PDDocument document = PDDocument.load(new File(pdfFilePath));

            // 이미지 삽입할 페이지 선택
            PDPage page = document.getPage(pageNumber);

            PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true);

            // 이미지 객체 생성
            if("SUBMIT".equals(signType)){

                PDImageXObject examin  = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.EXAMIN.val())), document);
                PDImageXObject check   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.CHECK.val())), document);
                PDImageXObject confirm = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.CONFIRM.val())), document);
                PDImageXObject write   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.WRITE.val())), document);

                // 검사자
                contentStream.drawImage(examin, 290, 775, 70,15);
                
                // 점검자
                contentStream.drawImage(check, 92, 120, 70,15);                
                // 점검일자
                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(232, 120, 50,15);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(236, 123);
                contentStream.showText(date);
                contentStream.endText();
                
                // 확인자
                contentStream.drawImage(confirm, 362, 120, 70,15);
                // 확인일자
                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(500, 120, 50,15);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(504, 123);
                contentStream.showText(date);
                contentStream.endText();

                //작성
                contentStream.drawImage(write, 375, 55, 50,20);

                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(377, 26, 55, 15);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(379, 29);
                contentStream.showText(date);
                contentStream.endText();

            }else if("RECEIPT".equals(signType)){

                PDImageXObject receipt   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.RECEIPT.val())), document);

                //검토
                contentStream.drawImage(receipt, 438, 55, 50,20);

                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(440, 26, 55, 15);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(442, 29);
                contentStream.showText(date);
                contentStream.endText();

            }else if("RECEIPT_CANCEL".equals(signType)){

                contentStream.setNonStrokingColor(255, 255, 255);

                contentStream.addRect(438, 55, 50,20);
                contentStream.fill();

                contentStream.addRect(440, 26, 55, 15);
                contentStream.fill();


            }else if("APPROVE".equals(signType)){

                PDImageXObject approve   = PDImageXObject.createFromFile(signInfo.get(signerInfo.get(SignType.APPROVE.val())), document);

                //승인
                contentStream.drawImage(approve, 503, 55, 50,20);

                contentStream.setNonStrokingColor(255, 255, 255);
                contentStream.addRect(505, 26, 55, 15);
                contentStream.fill();
                contentStream.setNonStrokingColor(0, 0, 0);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 10);
                contentStream.newLineAtOffset(507, 29);
                contentStream.showText(date);
                contentStream.endText();

            }

            contentStream.close();

            document.save(pdfFilePath);
            document.close();


        } catch (IOException e) {
            throw new MwfRuntimeException("서명시 오류가 발생하였습니다.");
        }
    }

}