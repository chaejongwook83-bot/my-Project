/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.sign.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;

/**
 * @author  jyp
 * @since   2021-06-24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-06-24      jyp        최초 생성
 * </pre>
 *
 */
@Data
public class SignInfo {
	
	//서명자 정보
    String signerDesc               = null;
        
    //서명정보
    CertInfo certInfo                 = null;
    
    //인증서 파일 정보
    Map<String, String> certFileMap = null;

    
    //속성정보
    Map<String, String> attr         = null;
    
    ArrayList<SignContract> signData        = null;        
    ArrayList<SignContract> signedData    = null;
    
    ArrayList<SignFileInfo> signFile        = null;
    ArrayList<SignFileInfo> signedFile    = null;
        
    public SignInfo() {
        this.signData   = new ArrayList<SignContract>();        
        this.signedData = new ArrayList<SignContract>();        
        
        this.signFile   = new ArrayList<SignFileInfo>();        
        this.signedFile = new ArrayList<SignFileInfo>();        
        
        this.attr        = new HashMap<String, String>();
    }
    
    
}
