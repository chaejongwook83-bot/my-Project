/*
 * Copyrightⓒ 2024. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.eform.vo;

/**
 * 서명타입
 */
public enum SignType {

        /** 작성자 **/
        WRITE("WRITE"),
        /** 작업자 **/
        WORK("WORK"),
        /** 검사자 **/
        EXAMIN("EXAMIN"),
        /** 점검자 **/
        CHECK("CHECK"),
        /** 확인자 **/
        CONFIRM("CONFIRM"),
        /** 청소자  **/
        CLEAN("CLEAN"),
        /** 접수자  **/
        RECEIPT("RECEIPT"),
        /** 승인자  **/
        APPROVE("APPROVE"),
        ;


        private final String val;
        SignType(String val) {
            this.val = val;
        }
        public String val() {
            return val;
        }
    }