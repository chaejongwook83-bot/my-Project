/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.service;

import com.matrix2b.ca.common.CommonService;
import com.matrix2b.mwf.exception.MwfAssert;
import com.matrix2b.mwf.model.MwfMap;
import com.matrix2b.mwf.mvc.MwfService;
import com.matrix2b.mwf.security.KeyEncryptor;
import com.matrix2b.mwf.util.BeanUtil;
import com.matrix2b.mwf.util.CommonUtil;
import com.matrix2b.srm.cm.mapper.SrmCommonMapper;
import com.matrix2b.sys.attachment.service.CommonTransFileService;
import com.matrix2b.sys.common.service.DocumentFlowService;
import com.matrix2b.sys.setup.service.CommonCodeService;
import com.matrix2b.sys.setup.service.ServiceTypeService;
import com.matrix2b.sys.setup.vo.ProcessMapDataVO;
import lombok.RequiredArgsConstructor;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * SrmCommonService.java
 * @author  M2B
 * @since   2021-10-01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2021-10-01      M2B      최초 생성
 * </pre>
 *
 */
@Service
@RequiredArgsConstructor
public class SrmCommonService extends MwfService {
    
    private final ServiceTypeService serviceTypeService;
    private final SrmCommonMapper    srmCommonMapper;
    private final CommonService      commonService;
    private final CommonTransFileService commonTransFileService;
    private final DocumentFlowService documentFlowService;
    private final KeyEncryptor keyEncryptor;
    
    
    /**
     * 업체 업무제한여부 조회
     * @param paramMap
     */
    public MwfMap<String, Object> selectVendorBlockCheck(MwfMap<String, Object> paramMap){
        return srmCommonMapper.selectVendorBlockCheck(paramMap);
    }

    /**
     * 현재날짜 yyyyMMddHHmmss 형식으로 리턴
     * @return
     */
    public String getCurrDate()  {
        return srmCommonMapper.selectSysdateString(); //CommonUtil.getDateString("yyyyMMddHHmmss");
    }

    /**
     * 견적 상태 조회
     * @param rqHuid
     * @return
     */
    public MwfMap<String, Object> selectRequestQuotationCloseCheck(String rqHuid) {
        MwfMap<String, Object> params = new MwfMap();
        params.put("RX_H_UID", rqHuid);
        params.put("USER_ID" , getUserModelPart().getUserId());

        return srmCommonMapper.selectRequestQuotationCloseCheck(params);
    }

    /**
     * 도급입찰 파트너사 견적 상태 조회
     * @param rqHuid
     * @param rxD2Uid
     * @return
     */
    public MwfMap<String, Object> selectRequestQuotationCloseCheckD2(String rqHuid, String rxD2Uid) {
        MwfMap<String, Object> params = new MwfMap();
        params.put("RX_H_UID", rqHuid);
        params.put("RX_D2_UID", rxD2Uid);
        params.put("SUPPLIER_FLAG", "Y");
        params.put("USER_ID" , getUserModelPart().getUserId());

        return srmCommonMapper.selectRequestQuotationCloseCheck(params);
    }

    /**
     * 도급입찰 평가 견적 상태 조회
     * @param rqHuid
     * @param rxD3Uid
     * @return
     */
    public MwfMap<String, Object> selectRequestQuotationCloseCheckD3(String rqHuid, String rxD3Uid) {
        MwfMap<String, Object> params = new MwfMap();
        params.put("RX_H_UID", rqHuid);
        params.put("RX_D3_UID", rxD3Uid);
        params.put("USER_ID" , getUserModelPart().getUserId());

        return srmCommonMapper.selectRequestQuotationCloseCheckD3(params);
    }

    /**
     * 견적/입찰 업체선정현황 체크
     * @param paramMap
     * @return
     */
    public MwfMap<String, Object> getRxSelStatus(MwfMap<String, Object> paramMap) {

//        List<BigInteger>       arrRqHUid  = getArrUid(paramMap, "RX_H_UID");
        String[] rxHUids = keyEncryptor.decryptBySplitChar(paramMap.getStringValue("RX_H_UIDS"), ",");
        MwfMap<String, Object> params = new MwfMap();
        params.put("RX_H_UIDS", rxHUids);

        return srmCommonMapper.getRxSelStatus(params);
    }

    /** DB 날짜 체크(나중에 공통으로)
     * @return
     */
    public MwfMap<String, Object> selectSysdateCheck(String checkTime) {
        MwfMap<String, Object> paramMap = new MwfMap<String, Object>();

        JSONObject formatter =  CommonUtil.getUserModelPart().getFormat();
		JSONObject date = (JSONObject)formatter.get("date");
		String format   = ((JSONObject)date.get("BASE")).get("mask").toString();

        paramMap.put("DATE_VALUE", checkTime);
        paramMap.put("DATE_FORMAT", format);
        return srmCommonMapper.selectSysdateCheck(paramMap);
    }

    /**
     * 구매물품 조회
     * @param priceTypeCode
     * @return
     */
    public List<MwfMap<String, Object>> getServiceCodeList(String priceTypeCode) {
        return serviceTypeService.getServiceCodeList(priceTypeCode);
    }
    
    /**
     * 구매물품 조회 (검색조건용)
     * @param priceTypeCode
     * @return
     */
    public List<Map<String, Object>> getServiceCodeListAll(String priceTypeCode) {
        return commonService.addAllOption(serviceTypeService.getServiceCodeListAll(priceTypeCode));
    }
    
    /**
     * 회사별 공통코드 리스트 조회
     * @param companyCode
     * @param classCode
     * @return
     */
    public List<MwfMap<String, Object>> getCompanyCommonCodeList(String companyCode, String classCode) {
        return BeanUtil.getBean(CommonCodeService.class).getGroupCodeList(getUserModelPart().getClientCode(), companyCode, "C", classCode);
    }

    /**
     * 첨부문서 연계 조회
     * @param paramMap
     * @return
     */
    public JSONArray getAttachDocFlowList(MwfMap<String, Object> paramMap) {
        JSONArray docFlowArray = new JSONArray();

        // 1. 문서연계 조회 후 Document FLow 정보를 모두 가져온다
        String clientCode     = paramMap.getStringValue("CLIENT_CODE");
        String stdProcessCode = paramMap.getStringValue("PROCESS_CODE");   // 문서연계 조회 기준 - 프로세스코드
        String stdDataUid     = paramMap.getStringValue("DATA_UID");       // 문서연계 조회 기준 - key
        List<ProcessMapDataVO> pmdVOList = documentFlowService.searchDocumentFlow(clientCode, stdProcessCode, new String[]{stdDataUid});

        // COL_NAME::DATA_UID 를 합쳤을때 중복되는 행은 제거한다. ( ex) PR_H_UID::123456 )
        Set<String> duplCheck = new HashSet<>();  // 중복 체크용 set
        pmdVOList = pmdVOList.stream().filter(map -> {  String key = map.getProgramPkCol() + "::" + map.getDataUid();
                                                        return duplCheck.add(key);
                                                     }).collect(Collectors.toCollection(ArrayList::new));



        // 2. 첨부연계 문서 구성
        // 공통코드에 설정해놓은 첨부문서연계 매핑 조회 (DOC_ATTATCH_FLOW_MAPPING)
        List<MwfMap<String, Object>> docKeymappingList = BeanUtil.getBean(CommonCodeService.class).getCommonCodeList("S", "ATTACH_DOC_FLOW_MAPPING");

        // 사용할 첨부문서 코드 필터링
        String[] targetAttachDocArr = paramMap.get("TARGET_ATTACH_DOC_NAME").toString().split("\\|");  // 구분자 "|"로 자르기
        List<MwfMap<String, Object>> targetDocKeymappingList = docKeymappingList.stream().filter(map -> { String code = map.get("CODE").toString();
                                                   return code != null && Arrays.stream(targetAttachDocArr).anyMatch(item -> item.equals(code));
                                                  }).collect(Collectors.toList());
        // 첨부문서코드 loop
        for(Map<String, Object> codeMap : targetDocKeymappingList){
            String docAttachCode = codeMap.get("CODE").toString();   // 첨부문서 코드
            String docAttachType = codeMap.get("NAME").toString();   // 첨부문서 구분명
            String pkColName     = codeMap.get("ATTR1").toString();  // 식별키 컬럼명

            // 문서연계 loop
            for(ProcessMapDataVO pmdVO :  pmdVOList) {
                // 문서연계 단일행
                String pmdPkColName = pmdVO.getProgramPkCol();       // 문서연계 - 식별키 컬럼명
                String pmdDataUid   = pmdVO.getDataUid().toString(); // 문서연계 - UID
                String pmdDocNo     = (String) pmdVO.getDataDocumentNo(); // 문서연계 - 문서번호

                
                // 문서연계의 Document 식별키컬럼명(ColName) 중에
                // 첨부연계 대상 식별키컬럼명과 일치하는 key가 있을 경우
                // 해당 식별키에 해당하는 첨부문서 모두 조회 후 add
                if(pkColName.equals(pmdPkColName)){

                    MwfMap<String, Object> params = new MwfMap<String, Object>();
                    params.put("ATTACH_DOC_NAME", docAttachCode);
                    params.put("ATTACH_DOC_UID" , pmdDataUid);

                    // 첨부파일 조회
                    List<Map<String, Object>> result = commonTransFileService.editAttachDocName(params);
                    for(Map<String, Object> map : result) {
                        JSONObject data = new JSONObject();

                        data.put("size", map.get("FILE_SIZE") );
                        data.put("name", map.get("FILE_NAME"));
                        data.put("link", keyEncryptor.encrypt(map.get("DOC_ATTACH_UID").toString()));
                        data.put("docAttachType", docAttachType);   // 첨부연계 문서구분을 위한 첨부파일 구분명
                        data.put("docNo", pmdDocNo);

                        // 첨부연계 Add
                        docFlowArray.add(data);
                    }
                }
            }
        }

        return docFlowArray;
    }


    /**
     * 구매 - 내부품의 승인자 정보 조회
     *
     * @param param
     * @return
     */
    public MwfMap<String, Object> selectInternalApprInfo(MwfMap<String,Object> param) {
        param.put("LOGIN_USER_LOCALE", getUserModelPart().getLocale());
        return srmCommonMapper.selectInternalApprInfo(param);
    }


    /**
     * 구매 - 코스트센터 정보 조회
     *
     * @param param
     * @return
     */
    public MwfMap<String, Object> selectCostCenterInfo(MwfMap<String,Object> param) {
        param.put("LOGIN_USER_LOCALE", getUserModelPart().getLocale());
        return srmCommonMapper.selectCostCenterInfo(param);
    }

    /**
     * 구매 - 대표 배송지 정보 조회
     * @return
     */
    public MwfMap<String, Object> selectDeliveryInfo() {
        MwfMap<String, Object> paramMap = new MwfMap<String, Object>();
        paramMap.put("LOGIN_USER_LOCALE", getUserModelPart().getLocale());
        paramMap.put("LOGIN_USER_ID", getUserModelPart().getUserId());
        return srmCommonMapper.selectDeliveryInfo(paramMap);
    }


    /**
     * 도급 휴일 제외한 +n일 이후 날짜 반환
     * @param stdDate 기준날짜(YYYYMMDD)
     * @param afterDay +n일 이후
     * @return 기준날짜+n일 이후의 날짜 반환(YYYYMMDD)
     */
    public MwfMap<String, Object> selectHolidayCheck(String stdDate, String afterDay) {
        MwfMap<String, Object> paramMap = new MwfMap<String, Object>();

        paramMap.put("STD_DATE", stdDate);
        paramMap.put("AFTER_DAY", afterDay);
        return srmCommonMapper.selectHolidayCheck(paramMap);
    }
    
    /**
     * 세금계산서 자채 정보
     * @param miD1UidList 자재 uid 모음
     * @param params 조회 파라미터
     * @return
     */
    public MwfMap<String, Object> getTaxInfoLocal(String taxHuid) {
        MwfAssert.notBlank(taxHuid, "Uid must not be null.");
        MwfMap<String, Object> info = new MwfMap<String, Object>();
       
        info.putAll(srmCommonMapper.selectTaxH(taxHuid));
        //info.put("itemList", srmCommonMapper.selectTaxD1(taxHuid));
        
        java.util.List<java.util.Map<String,Object>> list = new java.util.ArrayList<>();
        java.util.Map<String,Object> row1 = new java.util.HashMap<>();
        row1.put("name",info.get("ITEM_NAME1").toString());
        row1.put("quantity",null);
        row1.put("unitPrice",null);
        row1.put("supplyAmount",info.get("SUPPLY_PRICE").toString());
        row1.put("taxAmount",info.get("VAT_AMOUNT").toString());
        row1.put("remark","");
        list.add(row1);
        
        info.put("itemList", list);
        
        return info;
   }


}
