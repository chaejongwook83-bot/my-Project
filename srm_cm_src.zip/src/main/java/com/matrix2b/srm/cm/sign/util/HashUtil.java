package com.matrix2b.srm.cm.sign.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;  // 추가
import java.util.Base64;         // 추가

/**
 *  문자열 해시 생성 및 검증을 위한 유틸리티 클래스
 * @author  PYB
 * @since   2025-04-09
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2025-04-09     PYB        최초 생성
 * </pre>
 *
 */
public class HashUtil {

    private static final int SALT_LENGTH = 32; // 32 bytes salt
    private static final String DELIMITER = "$"; // Salt와 해시를 구분하는 구분자

    private HashUtil() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * 주어진 문자열에 대해 Salt를 포함한 SHA-512 해시를 생성합니다.
     * 반환 형식: salt$hash
     *
     * @param input 해시를 생성할 문자열
     * @return salt와 해시가 결합된 문자열 (salt$hash 형식)
     */
    public static String generateHashWithSalt(String input) {
        if (input == null) {
            input = "";
        }

        String salt = generateSalt();
        String hash = generateHashWithProvidedSalt(input, salt);
        return salt + DELIMITER + hash;
    }

    /**
     * 제공된 Salt를 사용하여 SHA-512 해시를 생성합니다.
     *
     * @param input 해시를 생성할 문자열
     * @param salt 사용할 salt
     * @return 생성된 SHA-512 해시 문자열
     */
    public static String generateHashWithProvidedSalt(String input, String salt) {
        if (input == null) {
            input = "";
        }

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-512");
            // Salt를 먼저 추가하고 그 다음 입력값을 추가
            digest.update(salt.getBytes(StandardCharsets.UTF_8));
            byte[] encodedHash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(encodedHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error initializing SHA-512 algorithm", e);
        }
    }

    /**
     * 랜덤 Salt를 생성합니다.
     *
     * @return Base64로 인코딩된 salt 문자열
     */
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /**
     * Salt가 포함된 해시와 입력값을 비교하여 유효성을 검증합니다.
     *
     * @param input 검증할 문자열
     * @param saltedHash salt$hash 형식의 문자열
     * @return 해시가 일치하면 true, 아니면 false
     */
    public static boolean validateHashWithSalt(String input, String saltedHash) {
        if (saltedHash == null || !saltedHash.contains(DELIMITER)) {
            return false;
        }

        String[] parts = saltedHash.split("\\" + DELIMITER);
        if (parts.length != 2) {
            return false;
        }

        String salt = parts[0];
        String expectedHash = parts[1];
        String generatedHash = generateHashWithProvidedSalt(input, salt);

        return expectedHash.equals(generatedHash);
    }

    /**
     * 바이트 배열을 16진수 문자열로 변환합니다.
     *
     * @param hash 바이트 배열
     * @return 16진수 문자열
     */
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

}
