/*
 * Copyrightⓒ (주)매트릭스투비. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of www.matrix2b.com.,LTD.
 */
package com.matrix2b.srm.cm.sign.vo;

import lombok.Data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * <pre>
 *  계약서 검증 VO
 * </pre>
 *
 * @author M1Y0184
 * @version 1.0
 * @date 2018. 7. 30. 오전 9:03:19
 */
/* -----------------------------------------------------------------------
 *  변경일             작성자             변경내용
 *  ----------- ------------------- ---------------------------------------
 *  2019. 6. 13.    PYB         최초 작성
 *  ----------------------------------------------------------------------
 */
@Data
public class VerifyVO {

    //계약 서식명
    String formName;

    //서명 유형
    String signCase;

    //운영사 서명
    byte[] systemSign;

    //운영사 서명 인증서
    String systemCertName;

    //시스템 서명검증 메시지
    String systemVerifyMessage;

    //협력사 인증서
    private List<String> partnerCertNames = new ArrayList<>();

    //협력사 서명검증 메시지
    String partnerVerifyMessage;

    //문서 식별번호
    String docUid;

    /**
     * 협력사 인증서 데이터
     */
    String partnerCertData;

    /**
     * 서명 원본 데이터(Hash)
     **/
    String originalData;

    // 2025.04.09(PYB) , 해시서명처리 추가 (원본 데이터 보관필드 추가)
    /**
     * 원본 데이터(text)
     **/
    String originValue;


    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName;
    }

    public byte[] getSystemSign() {
        return Arrays.copyOf(systemSign, systemSign.length);
    }

    public void setSystemSign(byte[] systemSign) {
        this.systemSign = systemSign;
    }

    public String getSystemCertName() {
        return systemCertName;
    }

    public void setSystemCertName(String systemCertName) {
        this.systemCertName = systemCertName;
    }

    public List<String> getPartnerCertNames() {
        return partnerCertNames;
    }

    public void setPartnerCertName(String partnerCertName) {
        if (partnerCertName != null && !partnerCertName.trim().isEmpty()) {
            partnerCertNames.add(partnerCertName.trim());
        }
    }

    public void setPartnerCertName(List<String> pCertNames) {
        this.partnerCertNames = pCertNames;
    }

    public String getSignCase() {
        return signCase;
    }

    public void setSignCase(String signCase) {
        this.signCase = signCase;
    }

    public String getSystemVerifyMessage() {
        return systemVerifyMessage;
    }

    public void setSystemVerifyMessage(String systemVerifyMessage) {
        this.systemVerifyMessage = systemVerifyMessage;
    }

    public String getPartnerVerifyMessage() {
        return partnerVerifyMessage;
    }

    public void setPartnerVerifyMessage(String partnerVerifyMessage) {
        this.partnerVerifyMessage = partnerVerifyMessage;
    }

    public String getDocUid() {
        return docUid;
    }

    public void setDocUid(String docUid) {
        this.docUid = docUid;
    }

    public String setPartnerCertData(String partnerCertData) {
        return this.partnerCertData = partnerCertData;
    }

    public String getPartnerCertData() {
        return this.partnerCertData;
    }

    public String getOriginalData() {
        return originalData;
    }

    public void setOriginalData(String originalData) {
        this.originalData = originalData;
    }
}
