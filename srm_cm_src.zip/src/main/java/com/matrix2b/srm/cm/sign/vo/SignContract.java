/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.sign.vo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @author  jyp
 * @since   2021-06-24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-06-24      jyp        최초 생성
 * </pre>
 *
 */
public class SignContract {
	
	//서명대상 계약서
    String contract                 = null;
    
    //서명 데이터
    byte[]   signedContract;
            
    //속성정보
    Map<String, String> attr         = null;
           
    public SignContract() {                
        this.attr        = new HashMap<String, String>();
    }
    
    public SignContract(String contract, byte[] signedContract) {             
        this.contract       = contract;
        this.signedContract = signedContract;
        this.attr           = new HashMap<String, String>();
    }
    
    /*-----------------------------------------------------------------
     * GETTER
     -----------------------------------------------------------------*/                                
    public String getAttr(String key){
        return this.attr.get(key);
    }
    
        
    public String getContract() {
        return contract.substring(0, contract.length());
    }
    
    
    public byte[] getSignedContract() {
        return Arrays.copyOf(signedContract, signedContract.length);
    }

    /*-----------------------------------------------------------------
     * SETTER
     -----------------------------------------------------------------*/
    public void addAttr(String key, String value){        
        this.attr.put(key, value);
    }    
    
    public void setContract(String contract) {
        this.contract = contract;
    }
    
    public void setSignedContract(byte[] signedContract) {
        this.signedContract = signedContract;
    }
    
}
