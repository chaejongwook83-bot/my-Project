/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.sign.vo;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

/**
 * @author  jyp
 * @since   2021-06-24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-06-24      jyp        최초 생성
 * </pre>
 *
 */
@Data
public class SignFileInfo {
	 //첨부서류 서명파일
    String fileName                 = null;
            
    //속성정보
    Map<String, String> attr         = null;
    
        
    public SignFileInfo() {                
        this.attr        = new HashMap<String, String>();
    }
}
