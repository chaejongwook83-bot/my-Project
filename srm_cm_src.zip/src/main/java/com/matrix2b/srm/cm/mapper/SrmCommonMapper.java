/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.matrix2b.mwf.model.MwfMap;

/**
 * @author  M2B
 * @since   2021-10-01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-10-01      M2B        최초 생성
 * </pre>
 *
 */
@Mapper
@Repository
public interface SrmCommonMapper {

    /** 업체 업무제한여부 조회
     * 
     * @param paramMap
     */
    MwfMap<String, Object> selectVendorBlockCheck(MwfMap<String, Object> paramMap);

    MwfMap<String, Object> selectRequestQuotationCloseCheck(MwfMap<String, Object> paramMap);

    MwfMap<String, Object> selectRequestQuotationCloseCheckD3(MwfMap<String, Object> paramMap);

    MwfMap<String, Object> getRxSelStatus(MwfMap<String, Object> paramMap);

    MwfMap<String, Object> selectSysdateCheck(MwfMap<String, Object> paramMap);

    /**
     * 현재날짜 yyyyMMddHHmmss 형식으로 리턴
     * @return
     */
    String selectSysdateString();


    /**
     * 구매 - 내부품의 승인자 정보 조회
     *   기안자의 조직경로의 모든 상위 조직을 조회하여, 특정 직책코드의 USER_ID를 가져온다.
     *
     *     FN_GET_INT_APPR_ID
     *       param1 : 기안자 ID
     *       param2 : 승인자 직책코드
     *
     * @param param
     * @return
     */
    MwfMap<String, Object> selectInternalApprInfo(MwfMap param);


    /**
     * 코스트 센터 정보 조회
     * @param paramMap
     * @return
     */
    MwfMap<String, Object> selectCostCenterInfo(MwfMap<String, Object> paramMap);

    /**
     * 대표 배송지 정보 조회
     * @param paramMap
     * @return
     */
    MwfMap<String, Object> selectDeliveryInfo(MwfMap<String, Object> paramMap);


    /**
     * 도급 휴일 제외한 +n일 이후 날짜 반환
     * @param paramMap
     * @return 기준날짜+n일 이후의 날짜 반환(YYYYMMDD)
     */
    MwfMap<String, Object> selectHolidayCheck(MwfMap<String, Object> paramMap);

    MwfMap<String, Object> selectTaxH(String taxHuid);

    List<MwfMap<String, Object>> selectTaxD1(String taxHuid);
}