/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.lov.controller;

import com.matrix2b.ca.common.CommonService;
import com.matrix2b.mdm.item.service.ItemClassService;
import com.matrix2b.mdm.item.service.SourcingGroupService;
import com.matrix2b.mwf.model.MwfMap;
import com.matrix2b.mwf.model.MwfResult;
import com.matrix2b.mwf.mvc.MwfController;
import com.matrix2b.mwf.ui.annotation.MwfAnnotation;
import com.matrix2b.mwf.util.CommonUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;

/**
 * @author  jyp
 * @since   2021-10-18
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-10-18      jyp        최초 생성
 * </pre>
 *
 */
@Controller
@RequestMapping("/srm/cm/lov")
@RequiredArgsConstructor
public class LovSrmCustomController extends MwfController{
    
    
    private final ItemClassService itemClassService;
    private final SourcingGroupService sourcingGroupService;
    private final CommonService commonService;
           
    /**
     * 액션호출
     * @param 
     * @return 결과메시지
     */
    @PostMapping("/LOV_ITEM_CLASS/SEARCH_TREE")
    @ResponseBody
    public MwfResult searchTree(MwfMap<String, Object> params) {
        
        MwfResult resultVO = createTransactionCompleteMessage();
        resultVO.getAttrs().put("TREE_LIST", itemClassService.getItemClassJsonList(params));
               
        return resultVO;
    }
    
    /**
     * 액션호출
     * @param 
     * @return 결과메시지
     */
    @PostMapping("/LOV_SOURCING_GROUP_CLASS/SEARCH_SOURCING_GROUP_TREE")
    @ResponseBody
    public MwfResult searchsSourcingGroupTree(MwfMap<String, Object> params) {

        MwfResult resultVO = createTransactionCompleteMessage();
        resultVO.getAttrs().put("TREE_LIST", sourcingGroupService.getSourcingGroupJsonList(params));
               
        return resultVO;
    }
    
    
    /**
     * 자재아이템 호출
     * @param 
     * @return 결과메시지
     */
    @PostMapping("/LOV_ITEM/FORWARD")
    public ModelAndView lovItemForward(ModelAndView mv, MwfMap<String, Object> params) {

        params.put("CLASS_LEVEL", "1");
        mv.addObject("soClassLevel1", commonService.addAllOption(itemClassService.selectItemClassLevelOptions(params)));
        mv.setViewName("/srm/cm/lov/LOV_ITEM");
        mv.addAllObjects(params);
               
        return mv;
    }
    /**
     * 자재아이템 호출
     * @param 
     * @return 결과메시지
     */
    @PostMapping("/LOV_SUPPLIER/FORWARD")
    public ModelAndView lovSupplierForward(ModelAndView mv, MwfMap<String, Object> params) {
        
        mv.addObject("soScgGroup", commonService.getSystemCodeListAll("SCG_GROUP"));
        mv.addObject("scgGroup", commonService.getSystemCodeList("SCG_GROUP"));       
        
        mv.setViewName("/srm/cm/lov/LOV_SUPPLIER");
        mv.addAllObjects(params);
               
        return mv;
    }

    /**
     * Lov조회
     * @param params  파라미터맵핑객체
     * @return
     */
    @RequestMapping(value="/LOV_SUPPLIER/SEARCH",method = RequestMethod.POST)
    @ResponseBody
    @MwfAnnotation
    public List<Map<String, Object>> doSearch( MwfMap params) {
        String mapperNS = "com.matrix2b.srm.cm.lov.mapper.LOV_SUPPLIER";
        String actionId = "SEARCH";

        CommonUtil.updateLovCompanyParam(params);

        return commonService.searchCommonLovList(mapperNS, actionId, params);
    }
    
    /**
     * 자재아이템 호출
     * @param 
     * @return 결과메시지
     */
    @PostMapping("/LOV_PURCHASE_PRICE/FORWARD")
    public ModelAndView lovPurchasePriceForward(ModelAndView mv, MwfMap<String, Object> params) {
        
        mv.addObject("soScgGroup", commonService.getSystemCodeListAll("SCG_GROUP"));

        mv.setViewName("/mdm/lov/LOV_PURCHASE_PRICE");
        mv.addAllObjects(params);
               
        return mv;
    }

    /**
     * 자재아이템 호출
     * @param
     * @return 결과메시지
     */
    @PostMapping("/LOV_PURCHASE_PRICE_INFO/FORWARD")
    public ModelAndView lovPurchasePriceInfoForward(ModelAndView mv, MwfMap<String, Object> params) {

        mv.setViewName("/mdm/lov/LOV_PURCHASE_PRICE_INFO");
        mv.addAllObjects(params);

        return mv;
    }

    /**
     * 자재아이템 호출
     * @param
     * @return 결과메시지
     */
    @PostMapping("/LOV_ITEM_UNIT_PRICE/FORWARD")
    public ModelAndView lovItemUnitPriceForward(ModelAndView mv, MwfMap<String, Object> params) {

        mv.addObject("soScgGroup", commonService.getSystemCodeListAll("SCG_GROUP"));
        mv.addObject("scgGroup", commonService.getSystemCodeList("SCG_GROUP"));

        mv.setViewName("/mdm/lov/LOV_ITEM_UNIT_PRICE");
        mv.addAllObjects(params);

        return mv;
    }

    /**
     * 화주사 호출
     * @param
     * @return 결과메시지
     */
    @PostMapping("/LOV_SHIPPER/FORWARD")
    public ModelAndView lovShipperForward(ModelAndView mv, MwfMap<String, Object> params) {

        mv.setViewName("/srm/cm/lov/LOV_SHIPPER");
        mv.addAllObjects(params);

        return mv;
    }

    /**
     * 레벨별 클래스패스 조회
     * @param params
     * @return
     */
    @PostMapping("/LOV_ITEM/GET_ITEM_CLASS_SELECT_BOX")
    @ResponseBody
    public MwfResult getEvaluationGroupList(MwfMap<String, Object> params){
        MwfResult result = createTransactionCompleteMessage();
        result.getAttrs().put("data", commonService.addAllOption(itemClassService.selectItemClassLevelOptions(params)));
        return result;
    }


}
