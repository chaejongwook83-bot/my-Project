/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.sign;

import com.matrix2b.mwf.exception.MwfRuntimeException;
import com.matrix2b.mwf.spring.property.SpringProperty;
import com.matrix2b.mwf.util.BeanUtil;
import com.matrix2b.srm.cm.sign.vo.SignContract;
import com.matrix2b.srm.cm.sign.vo.SignInfo;
import com.matrix2b.sys.ext.sign.tradeSign.JeTSInitializer;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import tradesign.crypto.cert.validator.ExtendedPKIXParameters;
import tradesign.crypto.cert.validator.PKIXCertPath;
import tradesign.crypto.provider.JeTS;
import tradesign.pki.pkix.SignedData;
import tradesign.pki.pkix.X509Certificate;
import tradesign.pki.util.JetsUtil;

import java.security.cert.CertPathValidator;
import java.security.cert.CertificateExpiredException;
import java.security.cert.PKIXCertPathValidatorResult;
import java.util.Base64;

/**
 * @author  jyp
 * @since   2021-06-24
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용          
 *  ==========    ==========    ============================ 
 *  2021-06-24      jyp        최초 생성
 * </pre>
 *
 */
@Log4j2
public class TradeSign implements SignKit {
        //최대 재접속 횟수
        //private static int MAX_RECONNECT_CNT = 3;
        
        // 인증서 ID
        private int certIdx;  
            
        //현재 재접속 횟수
        //private int currConnectCount  = 0;  
                
        public TradeSign(String companyCode) {
            
            JeTSInitializer.init();
            
            if("100".equals(companyCode)) {
                this.certIdx = 0;
            }

        }
        
        
        
        /**
         * 운영사 서명
         */
        @Override
        public void envelopd(SignInfo signInfo) throws Exception {
                                           
            //계약 서명
            for(int i = 0 ; i < signInfo.getSignData().size() ; i++){
                            
                SignContract sc = signInfo.getSignData().get(i);
                
                String data = sc.getContract();                        
                                        
                SignedData sd = new SignedData(data.getBytes(), true);
                
                verifyCert(JeTS.getServerSignCert(this.certIdx));
                sd.setsignCert(JeTS.getServerSignCert(this.certIdx), JeTS.getServerSignPriKey(this.certIdx), JeTS.getServerSignKeyPassword(this.certIdx));                       
                
                byte[] signedMsg = sd.sign();
                                                    
                SignContract signedSc = new SignContract();
                signedSc.setSignedContract(signedMsg);
                signedSc.addAttr("TARGET_UID", sc.getAttr("TARGET_UID"));
                signedSc.addAttr("SIGN_CASE" , sc.getAttr("SIGN_CASE"));
                            
                signInfo.getSignedData().add(signedSc);                                    
            }                   
                                            
        }
        
        /**
         * 협력업체 서명
         */
         @Override
        public SignContract sign(String data, String orgData) throws Exception {


            verifyCert(JeTS.getServerSignCert(this.certIdx));
            SignedData sd = new SignedData(data.getBytes(), true);
            sd.setIncludeSigningTime(true);
            sd.setsignCert(JeTS.getServerSignCert(this.certIdx), JeTS.getServerSignPriKey(this.certIdx), JeTS.getServerSignKeyPassword(this.certIdx));
            byte[] signedMsg = sd.sign();
                    
            SignContract sc = new SignContract(data, signedMsg);
            sc.addAttr("USE_CERT", "-----BEGIN CERTIFICATE-----" + Base64.getEncoder().encodeToString(JeTS.getServerSignCert(this.certIdx))+"-----END CERTIFICATE-----");

            SignedData sdTmp = new SignedData(signedMsg);
            log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            log.info("서버서명데이터 : "+ new String(sdTmp.getContent()));
            log.info("협력사데이터   : "+ data);
            log.info("동일여부      : "+ StringUtils.equals(new String(sdTmp.getContent()),data));
            X509Certificate[] certs = sdTmp.verify();
            for (int i = 0; i < certs.length; i++)
            {
                PKIXCertPath cp = new PKIXCertPath(certs[i], "PkiPath");
                ExtendedPKIXParameters cpp = new ExtendedPKIXParameters(JeTS.getTAnchorSet());
                CertPathValidator cpvi = CertPathValidator.getInstance("PKIX","JeTS");
                PKIXCertPathValidatorResult cpvr = (PKIXCertPathValidatorResult) cpvi.validate(cp, cpp);
                log.info("검증성공:" + certs[i].getSubjectDNStr());
                log.info("서명시간:" + sdTmp.getSigningTime());
            }
            log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            SignedData psd = new SignedData(JetsUtil.decodeBase64(sdTmp.getContent()));
            log.info("협력사서명데이터 : "+ new String(psd.getContent()));
            log.info("원본           : "+ orgData);
            log.info("동일여부      : "+ StringUtils.equals(new String(psd.getContent()),orgData));
            certs = psd.verify();
            for (int i = 0; i < certs.length; i++)
            {
                PKIXCertPath cp = new PKIXCertPath(certs[i], "PkiPath");
                ExtendedPKIXParameters cpp = new ExtendedPKIXParameters(JeTS.getTAnchorSet());
                CertPathValidator cpvi = CertPathValidator.getInstance("PKIX","JeTS");
                PKIXCertPathValidatorResult cpvr = (PKIXCertPathValidatorResult) cpvi.validate(cp, cpp);
                log.info("검증성공:" + certs[i].getSubjectDNStr());
                log.info("서명시간:" + psd.getSigningTime());
            }
            // 서명검증
            log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

            return sc;
        }
        
        /**
         * 인증서 유효성 체크
         * @param certData   인증서 데이터
         * @throws Exception 인증서 유효성 체크 오류 시
         */
        private void verifyCert(byte[] certData) throws Exception {
            
            //운영모드에서만 인증서 유효성체크 추가
            SpringProperty springProperty = BeanUtil.getBean(SpringProperty.class);
            boolean prodMode = springProperty.isProductionMode();
            if(prodMode) {
                try {            
                    //인증서정보
                    X509Certificate cert = new X509Certificate(certData);
                    
                    PKIXCertPath cp = new PKIXCertPath(cert, "PkiPath");
                    ExtendedPKIXParameters cpp = new ExtendedPKIXParameters(JeTS.getTAnchorSet());
                    CertPathValidator cpvi = CertPathValidator.getInstance("PKIX","JeTS");
                    //synchronized (TradeSign.class) {
                        cpvi.validate(cp, cpp);
                    //}
                   
                }catch(CertificateExpiredException e) {
                    String msg = e.getMessage();
                    
                    msg = msg.replaceAll("java.security.cert.CertificateExpiredException", "");
                    MwfRuntimeException mwfe = new MwfRuntimeException(msg);
                    mwfe.setStackTrace(e.getStackTrace());
                    throw mwfe;
                    
                    
                } 
                /*   Unreachable catch block for UnknownHostException. This exception is never thrown from the try statement body
                    catch(UnknownHostException ea) {
                    String msg = ea.getMessage();
                     //재전송 시작
                    if (msg.indexOf("java.net.UnknownHostException") > -1) {
                        this.currConnectCount++;
                        if (this.currConnectCount <= this.MAX_RECONNECT_CNT) {
                            log.debug("MWF_LOGGER", "Re-Connect : " + this.currConnectCount + " : " + this.MAX_RECONNECT_CNT);
                            //2초간 중단
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e1) {
                                log.error("MWF_LOGGER", e1);
                            }
                            verifyCert(certData);
                        } else {
                            throw ea;
                        }
                    }
                }
                
                */
            }
            
        }
        
        
}
