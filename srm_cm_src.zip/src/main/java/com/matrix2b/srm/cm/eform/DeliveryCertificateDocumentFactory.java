/*
 * Copyrightⓒ 2024. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.eform;

import java.util.HashMap;

/**
 * 생산서류 생성 클래스
 * @author  PYB
 * @since   2024-07-16
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일        수정자                수정내용
 *  ==========    ==========    ============================
 *  2024-07-16      PYB          최초 생성
 * </pre>
 *
 */
public class DeliveryCertificateDocumentFactory {

    public DeliveryCertificateDocument getDeliveryCertificateDocument(String formCode, HashMap<String, String> signerInfo, HashMap<String, String> signInfo, String fileInfo) {
        if (formCode == null) {
            return null;
        }
        if ("MM_PO1300".equalsIgnoreCase(formCode)) {
            return new MM_PO1300(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO1600".equalsIgnoreCase(formCode)) {
            return new MM_PO1600(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2110".equalsIgnoreCase(formCode)) {
            return new MM_PO2110(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2210".equalsIgnoreCase(formCode)) {
            return new MM_PO2210(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2310".equalsIgnoreCase(formCode)) {
            return new MM_PO2310(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2420".equalsIgnoreCase(formCode)) {
            return new MM_PO2420(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2800".equalsIgnoreCase(formCode)) {
            return new MM_PO2800(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2900".equalsIgnoreCase(formCode)) {
            return new MM_PO2900(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2910".equalsIgnoreCase(formCode)) {
            return new MM_PO2910(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2120".equalsIgnoreCase(formCode)) {
            return new MM_PO2120(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2510".equalsIgnoreCase(formCode)) {
            return new MM_PO2510(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2520".equalsIgnoreCase(formCode)) {
            return new MM_PO2520(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2400".equalsIgnoreCase(formCode)) {
            return new MM_PO2400(signerInfo, signInfo, fileInfo);
        }else if ("MM_PO2220".equalsIgnoreCase(formCode)) {
            return new MM_PO2220(signerInfo, signInfo, fileInfo);
        }
        return null;
    }
}