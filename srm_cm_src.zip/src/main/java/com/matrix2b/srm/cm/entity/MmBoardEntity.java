/*
 * Copyrightⓒ 2021. (주)매트릭스투비 All rights reserved.
 */
package com.matrix2b.srm.cm.entity;

import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.Date;

import com.matrix2b.mwf.model.entity.MwfEntity;
import com.matrix2b.mwf.model.entity.annotation.*;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * 구매-게시판 Entity (MM_BOARD)
 *
 * @author  sonyh
 * @version 1.0
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *
 *    수정일         수정자                수정내용
 *  ==========    ==========    ============================
 *  2025-07-17    sonyh        최초 생성
 * </pre>
 *
 */
@Setter
@Getter
@Table("MM_BOARD")
public class MmBoardEntity extends MwfEntity {

    @NotNull
    @Digits(integer=22, fraction=0)
    @Column(name="BOARD_UID", label="게시판 식별번호", type=DataType.NUMBER, primaryKey=true)
    private BigInteger boardUid;

    @NotNull
    @Size(max=30)
    @Column(name="CLIENT_CODE", label="그룹코드")
    private String clientCode;

    @Size(max=30)
    @Column(name="COMPANY_CODE", label="회사코드")
    private String companyCode;

    @Size(max=15)
    @Column(name="STATUS", label="상태")
    private String status;

    @NotNull
    @Size(max=1)
    @Column(name="TRS_CODE", label="트랜잭션코드")
    @ColumnTransformer(type=TransformType.TRANSACTION_CODE)
    private String trsCode;

    @NotNull
    @Size(max=1)
    @Column(name="ACTV_FLAG", label="활성여부")
    @ColumnTransformer(type=TransformType.ACTIVE_FLAG)
    private String actvFlag;

    @NotNull
    @Size(max=35)
    @Column(name="REG_ID", label="등록자")
    @ColumnTransformer(type=TransformType.USER_ID, when=StatementType.INSERT)
    private String regId;

    @NotNull
    @Column(name="REG_DATE", label="등록일", type=DataType.DATETIME)
    @ColumnTransformer(type=TransformType.NOW, when=StatementType.INSERT)
    private Date regDate;

    @Size(max=35)
    @Column(name="MOD_ID", label="수정자")
    @ColumnTransformer(type=TransformType.USER_ID)
    private String modId;

    @Column(name="MOD_DATE", label="수정일", type=DataType.DATETIME)
    @ColumnTransformer(type=TransformType.NOW)
    private Date modDate;

    @Size(max=300)
    @Column(name="TITLE", label="제목")
    private String title;

    @Column(name="CONTENT", label="내용", type=DataType.CLOB)
    private String content;

    @Size(max=10)
    @Column(name="DOC_TYPE_CODE", label="문서타입 (RX: RFx소통)")
    private String docTypeCode;

    @Digits(integer=22, fraction=0)
    @Column(name="DOC_UID", label="문서식별번호", type=DataType.NUMBER)
    private BigInteger docUid;

    @Size(max=10)
    @Column(name="REG_TYPE_CODE", label="작성자구분(H:회사, V:벤더)")
    private String regTypeCode;

    @Size(max=30)
    @Column(name="SUPPLIER_CODE", label="협력업체코드")
    private String supplierCode;

    @Size(max=1)
    @Column(name="CONFIRM_FLAG", label="검토여부")
    private String confirmFlag;

    @Size(max=30)
    @Column(name="CONFIRM_USER_ID", label="검토자")
    private String confirmUserId;
}
