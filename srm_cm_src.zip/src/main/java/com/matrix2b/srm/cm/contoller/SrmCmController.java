package com.matrix2b.srm.cm.contoller;

import org.json.simple.JSONArray;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.matrix2b.mwf.model.MwfMap;
import com.matrix2b.mwf.model.MwfResult;
import com.matrix2b.mwf.security.KeyEncryptor;
import com.matrix2b.srm.cm.service.SrmCommonService;
import com.matrix2b.sys.setup.service.ServiceTypeService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/srm/cm/common")
@RequiredArgsConstructor
public class SrmCmController {
	
	private final SrmCommonService srmCommonService;

    private final KeyEncryptor keyEncryptor;
    
    private final ServiceTypeService serviceTypeService;
      
	
	/**
     * 타이머
     */
    @RequestMapping(value = "/coolDown", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public ModelAndView coolDown(ModelAndView mv) {
        mv.setViewName("/srm/cm/timer/cooldown");     
        return mv;
    }
    
    /**
     * 현재시간 리턴
     * @param 
     * @return 결과메시지
     */
    @RequestMapping(value = "/GET_CURR_DATE" , method = {RequestMethod.POST, RequestMethod.GET} )
    @ResponseBody
    public MwfResult getCurrDate() {
    	MwfResult resultVO = new MwfResult();
        resultVO.setCode("I-0001");
        resultVO.setSuccess(true);
        
        resultVO.getAttrs().put("CURR_DATE", srmCommonService.getCurrDate());
        return resultVO;
    }

    /**
     *  견적 상태 조회
     * @param rqHUid
     * @return
     */
    @PostMapping("/GET_RX_CLOSE_CHECK")
    @ResponseBody
    public MwfMap<String, Object> getRequestQuotationPurchasePrice(String rqHUid)  {
        return srmCommonService.selectRequestQuotationCloseCheck(keyEncryptor.decrypt(rqHUid));
    }

    /**
     * 도급입찰 파트너사 견적 상태 조회
     * @param rqHUid
     * @param rxD2Uid
     * @return
     */
    @PostMapping("/GET_RX_CLOSE_CHECK_D2")
    @ResponseBody
    public MwfMap<String, Object> getRequestQuotationPurchasePriceD2(String rqHUid, String rxD2Uid)  {
        return srmCommonService.selectRequestQuotationCloseCheckD2(keyEncryptor.decrypt(rqHUid), keyEncryptor.decrypt(rxD2Uid));
    }

    /**
     * 도급입찰 평가 견적 상태 조회
     * @param rqHUid
     * @param rxD3Uid
     * @return
     */
    @PostMapping("/GET_RX_CLOSE_CHECK_D3")
    @ResponseBody
    public MwfMap<String, Object> getRequestQuotationPurchasePriceD3(String rqHUid, String rxD3Uid)  {
        return srmCommonService.selectRequestQuotationCloseCheckD3(keyEncryptor.decrypt(rqHUid), keyEncryptor.decrypt(rxD3Uid));
    }

    /**
     *  DB 날짜 체크
     * @param checkTime
     * @return
     */
    @PostMapping("/GET_SYSDATE_CHECK")
    @ResponseBody
    public MwfMap<String, Object> getSysdateCheck(String checkTime) {
        return srmCommonService.selectSysdateCheck(checkTime);
    }
    
    /**
     *  사용자 서명
     * @return
     */
    @PostMapping("/USER_SIGNATURE")
    public ModelAndView signature() {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("/srm/cm/common/USER_SIGNATURE");
        return mv;
    }
    
    /**
     * 구매물품 조회
     * @param priceTypeCode 구매유형
     * @return
     */
    @PostMapping("/GET_SERVICE_TYPE_CODE")
    @ResponseBody
    public MwfResult getServiceTypeCode(String priceTypeCode) {
        MwfResult resultVO = new MwfResult();
        resultVO.setCode("I-0001");
        resultVO.setSuccess(true);
        
        resultVO.getAttrs().put("data", srmCommonService.getServiceCodeList(priceTypeCode));        
        return resultVO;
    }
    
    /**
     * 구매프로세스 설정 조회
     * @param paramMap
     * @return
     */
    @PostMapping("/GET_PURCHASE_PROCESS")
    @ResponseBody
    public MwfResult getSpecsFlag(MwfMap<String, String> paramMap) {
        MwfResult resultVO = new MwfResult();
        resultVO.setCode("I-0001");
        resultVO.setSuccess(true);
        resultVO.getAttrs().put("data", serviceTypeService.getServiceCode(paramMap.get("CLIENT_CODE"), paramMap.get("SERVICE_TYPE_CODE")));
        return resultVO;
    }

    /**
    * 견적/입찰 업체선정현황 체크
    * @param paramMap
    * @return
    */
   @PostMapping("/GET_RX_SEL_STATUS")
   @ResponseBody
   public MwfResult getRxSelStatus(MwfMap<String, Object> paramMap) {
       MwfResult resultVO = new MwfResult();
       resultVO.setCode("I-0001");
       resultVO.setSuccess(true);
       resultVO.getAttrs().put("data", srmCommonService.getRxSelStatus(paramMap));

       return resultVO;
   }
    
    /**
     * 회사별 공통코드 리스트 조회
     * @param params
     * @return
     */
    @PostMapping("/GET_COMPANY_COMMON_CODE")
    @ResponseBody
    public MwfResult getCompanyCommonCode(MwfMap<String, String> params) {
        MwfResult resultVO = new MwfResult();
        resultVO.setCode("I-0001");
        resultVO.setSuccess(true);
        
        resultVO.getAttrs().put("data", srmCommonService.getCompanyCommonCodeList(params.get("COMPANY_CODE"), params.get("CLASS_CODE")));        
        return resultVO;
    }


    /**
     * 첨부문서 연계 조회 (2025.05.13 추가 - 황상무님 요청)
     *
     * @param params
     * @return
     */
    @PostMapping("/GET_ATTACH_DOC_FLOW")
    @ResponseBody
    public MwfResult getAttachDocFlow(@RequestBody MwfMap<String, Object> params) {
        // *** 첨부연계 ***
        //    - 문서연계에 매핑된 모듈 문서별 key를 모두 조회하여,
        //    - 프로세스가 진행되는 동안 첨부된 모든 첨부파일을 일괄로 확인할 수 있도록 함.

        JSONArray jsonArray = srmCommonService.getAttachDocFlowList(params);

        MwfResult resultVO = new MwfResult();
        resultVO.setCode("I-0001");
        resultVO.setSuccess(true);
        resultVO.getAttrs().put("data", jsonArray);

        return resultVO;
    }

    /**
     * 도급 휴일 제외한 +n일 이후 날짜 반환
     * @param stdDate 기준날짜(YYYYMMDD)
     * @param afterDay +n일 이후
     * @return 기준날짜+n일 이후의 날짜 반환(YYYYMMDD)
     */
    @PostMapping("/GET_HOLIDAY_CHECK")
    @ResponseBody
    public MwfMap<String, Object> getHolidayCheck(String stdDate, String afterDay) {
        return srmCommonService.selectHolidayCheck(stdDate, afterDay);
    }
    
    
    /**
     * 매입세금계산서 관련 세금계산서 양식 상세 화면 
     * @param taxHuid 
     * @param 
     * @return 세금계산서 상세 정보
     */
    @RequestMapping(value = "/FORWARD_TAX_INFO/{taxUidOrg}" , method = {RequestMethod.POST, RequestMethod.GET} )
    @ResponseBody
    public ModelAndView forwardTaxInfoPage(ModelAndView mv, @PathVariable String taxUidOrg){
       
        
        MwfMap<String, Object> mmPoMap = srmCommonService.getTaxInfoLocal(taxUidOrg);
        
        mv.addAllObjects(mmPoMap);        
        mv.setViewName("/srm/cm/common/tax_info");
        
        return mv;
    }
    
}
